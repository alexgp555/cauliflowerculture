<!-- ============================================== CART STYLE-V1 ============================================== -->
<a href="#" class="dropdown-toggle lnk-cart" data-toggle="dropdown">
	<div class="items-cart-inner">
		<div class="total-price-basket">
			<i class="fa fa-shopping-cart"></i>
			<span class="lbl">my cart</span>
			<span class="cart-count">(02)</span>
		</div><!-- /.total-price-basket -->
    </div><!-- /.items-cart-inner -->
</a>
<!-- ============================================== CART STYLE-V1 : END ============================================== -->