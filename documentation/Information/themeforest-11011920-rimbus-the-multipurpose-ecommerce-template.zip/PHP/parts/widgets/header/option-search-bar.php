<!-- ============================================== OPTION SEARCH BAR ============================================== -->
<div class="option-search-bar">
	<div class="input-group">
		
      	<div class="category-menu input-group-btn">
        	<div class="custom-select">
				<ul class="list-unstyled">
					<li class="country">
			            <select class="styled">
				            <option>Category</option>
							<option>option-1</option>
							<option>option-2</option>
							<option>option-3</option>
							<option>option-4</option>
							<option>option-5</option>
			            </select>
			        </li>
			    </ul>
			</div>
      	</div><!-- /btn-group -->
		
      	<input type="text" class="form-control" placeholder="Search...">

      	<span class="input-group-btn">
	        <button class="btn" type="button"><i class="fa fa-search"></i></button>
	    </span><!-- /input-group-btn -->

    </div><!-- /input-group -->
</div><!-- /option-search-bar -->
<!-- ============================================== OPTION SEARCH BAR : END============================================== -->