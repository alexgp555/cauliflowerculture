<!-- ============================================== LANGUAGE CURRENCY ============================================== -->
<ul class="list-unstyled list-inline">
    
    <li class="dropdown dropdown-small">
        <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown"><span class="value"><img src="assets/images/flag/1.jpg" alt="#">eng <i class="fa fa-angle-down"></i></span></a>
        <ul class="dropdown-menu fadeIn animated">
            <li><a href="#"><img src="assets/images/flag/2.jpg" alt="#"> fra</a></li>
            <li><a href="#"><img src="assets/images/flag/3.jpg" alt="#"> deu</a></li>
        </ul>
    </li>

    <li class="dropdown dropdown-small">
        <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown"><span class="value"><i class="fa fa-usd"></i> USD <i class="fa fa-angle-down"></i></span></a>
        <ul class="dropdown-menu fadeIn animated">
            <li><a href="#"><span class="value"><i class="fa fa-inr"></i> inr</span></a></li>
            <li><a href="#"><span class="value"><i class="fa fa-gbp"></i> gbp</span></a></li>
        </ul>
    </li>
    
</ul><!-- /.nav -->
<!-- ============================================== LANGUAGE CURRENCY  ============================================== -->