<!-- ============================================== CART STYLE-V6 ============================================== -->
<a href="#" class="dropdown-toggle lnk-cart" data-hover="dropdown" data-toggle="dropdown">
	<div class="items-cart-inner">

		<div class="total-price-basket">
			<i class="fa fa-shopping-cart"></i>
			<span class="cart-count">(01)</span>
		</div><!-- /.total-price-basket -->
	
    </div><!-- /.items-cart-inner -->
</a>
<!-- ============================================== CART STYLE-V6 : END ============================================== -->