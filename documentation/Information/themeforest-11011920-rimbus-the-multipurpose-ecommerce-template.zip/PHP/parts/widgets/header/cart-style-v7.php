<!-- ============================================== CART STYLE-V7 ============================================== -->
<a href="#" class="dropdown-toggle lnk-cart" data-hover="dropdown" data-toggle="dropdown">
	<div class="items-cart-inner">

		<div class="total-price-basket ">
			<span class="cart-icon"><i class="fa fa-shopping-cart"></i><span class="item-count">01</span></span>
			<span class="cart-info">
				<span class="label-name">my cart</span>
				<span class="amount">$456.00</span>
			</span>
		</div><!-- /.total-price-basket -->
	
    </div><!-- /.items-cart-inner -->
</a>
<!-- ============================================== CART STYLE-V7 : END ============================================== -->