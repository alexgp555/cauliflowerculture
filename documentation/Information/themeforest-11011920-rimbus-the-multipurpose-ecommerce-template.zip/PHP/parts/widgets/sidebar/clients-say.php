<!-- ============================================== CLIENT SAY ============================================== -->
<h3 class="section-title">clients say</h3>
<div class="clients-say">
	
	<div class="item">
		<div class="content-box">
			<p class="content">“ Sed a mollis libero. Sed aliquet , toro vel effics itur finibus, nunc felis hendd rerit nula non auct or lectus erat velm.</p>
		</div>
		<div class="client-info media">
			<div class="media-left">
				<img src="assets/images/testimonial/1.jpg" alt="" class="img-responsive">
			</div>
			<div class="media-body client-name">
				<h4>jone doe</h4>
				<span class="client-company">Envato - Themes</span>
			</div>
	    </div>
    </div>
    <div class="item">
		<div class="content-box">
			<p class="content">“ Sed a mollis libero. Sed aliquet , toro vel effics itur finibus, nunc felis hendd rerit nula non auct or lectus erat velm.</p>
		</div>
		<div class="client-info media">
			<div class="media-left">
				<img src="assets/images/testimonial/1.jpg" alt="" class="img-responsive">
			</div>
			<div class="media-body client-name">
				<h4>jone doe</h4>
				<span class="client-company">Envato - Themes</span>
			</div>
	    </div>
    </div>
    <div class="item">
		<div class="content-box">
			<p class="content">“ Sed a mollis libero. Sed aliquet , toro vel effics itur finibus, nunc felis hendd rerit nula non auct or lectus erat velm.</p>
		</div>
		<div class="client-info media">
			<div class="media-left">
				<img src="assets/images/testimonial/1.jpg" alt="" class="img-responsive">
			</div>
			<div class="media-body client-name">
				<h4>jone doe</h4>
				<span class="client-company">Envato - Themes</span>
			</div>
	    </div>
    </div>

</div><!-- /.clients-say -->
<!-- ============================================== CLIENT SAY : END ============================================== -->