<!-- ============================================== SIDEBAR CATEGORY ITEMS ============================================== -->
<ul>
	<li>		
		<div class="checkbox">
            <label>
            	<input type="checkbox"> Clothing
            </label>
        </div>		
	</li>
	<li>
		<div class="checkbox">
            <label>
            	<input type="checkbox"> Footwear
            </label>
        </div>
	</li>
	<li>
		<div class="checkbox">
            <label>
            	<input type="checkbox"> Bags, Belts & Wallets
            </label>
        </div>
	</li>
	<li>
		<div class="checkbox">
            <label>
            	<input type="checkbox"> Watches
            </label>
        </div>
		
	</li>
	<li>
		<div class="checkbox">
            <label>
            	<input type="checkbox"> Beauty & Wellness
            </label>
        </div>
		
	</li>
	<li>
		<div class="checkbox">
            <label>
            	<input type="checkbox"> Perfumes
            </label>
        </div>
	</li>
</ul>
<!-- ============================================== SIDEBAR CATEGORY ITEMS : END ============================================== -->
