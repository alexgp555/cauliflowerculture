<!-- ============================================== SINGLE BANNER ============================================== -->
<div class="single-banner wow fadeIn" data-wow-delay="0.2s">
	<a href="#">
	    <div class="content"><span class="line-1">sale 30%<span class="line-2">off</span></span></div>
	    <div class="image">
	    	<img src="assets/images/banners/8.jpg" alt="#">
	 	</div>
    </a>
</div><!-- /.single-banner -->
<!-- ============================================== SINGLE BANNER : END ============================================== -->
