<!-- ============================================== PRODUCT TAGS ============================================== -->
<div class="product-tag wow fadeIn">
	<h3 class="section-title">Tags</h3>
	<div class="tag-list">					
		<a href="index.php?page=category-v1" title="Fashion" class="item">Fashion</a>
		<a href="index.php?page=category-v1" title="Women’s" class="item">Women’s</a>
		<a href="index.php?page=category-v1" title="Kids" class="item">Kids</a>
		<a href="index.php?page=category-v1" title="Lookbook" class="item">Lookbook</a>
		<a href="index.php?page=category-v1" title="Accessories" class="item">Accessories</a>
		<a href="index.php?page=category-v1" title="Dress" class="item">Dress</a>
		<a href="index.php?page=category-v1" title="Sale Off" class="item">Sale Off</a>
		<a href="index.php?page=category-v1" title="Accessories" class="item active">Accessories</a>
		<a href="index.php?page=category-v1" title="Clothing" class="item">Clothing</a>
		<a href="index.php?page=category-v1" title="Clothing" class="item">Clothing</a>
		<a href="index.php?page=category-v1" title="Men's" class="item">Men's</a>
		<a href="index.php?page=category-v1" title="Carry bag" class="item">Carry bag</a>
	</div>
</div><!-- /.product-tag -->
<!-- ============================================== PRODUCT TAGS : END ============================================== -->