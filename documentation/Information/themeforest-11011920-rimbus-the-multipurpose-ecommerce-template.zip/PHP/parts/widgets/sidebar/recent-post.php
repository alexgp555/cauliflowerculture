<!-- ============================================== RECENT POST ============================================== -->
<div class="recent-post wow fadeIn">
	<h3 class="section-title">recent post</h3>
	<ul class="list-group">
		<li class="list-group-item">
			<span class="date">JAN 29, 2015</span>
			<span class="content">Quisque faucibus enim non tempus gravis da Morbi non sem sagittis, venenatis neqd ue. consequat justo sem [ <a href="#" class="more">more</a> ]</span>
		</li>
		<li class="list-group-item">
			<span class="date">JAN 29, 2015</span>
			<span class="content">Quisque faucibus enim non tempus gravis da Morbi non sem sagittis, venenatis neqd ue. consequat justo sem [ <a href="#" class="more">more</a> ]</span>
		</li>
		<li class="list-group-item">
			<span class="date">JAN 29, 2015</span>
			<span class="content">Quisque faucibus enim non tempus gravis da Morbi non sem sagittis, venenatis neqd ue. consequat justo sem [ <a href="#" class="more">more</a> ]</span>
		</li>
	</ul>
</div><!-- /.recent-post -->
<!-- ============================================== RECENT POST : END ============================================== -->