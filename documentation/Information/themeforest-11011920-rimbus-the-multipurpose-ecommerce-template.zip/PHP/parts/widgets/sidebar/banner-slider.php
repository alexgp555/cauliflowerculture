<!-- ============================================== BANNER SLIDER ============================================== -->
<div class="banner-slider wow fadeIn" data-wow-delay="0.2s">
	<div class="item">
		<div class="banner-outer">
			<div class="text">
				<h4>new design</h4>
				<h2>fashion</h2>
				<a class="shop-now" href="#">Shop now ></a>
			</div>
			<img src="assets/images/banners/4.jpg" alt="#" class="img-responsive">
		</div>
	</div><!-- /.item -->
	<div class="item">
		<div class="banner-outer">
			<div class="text">
				<h4>new design</h4>
				<h2>fashion</h2>
				<a class="shop-now" href="#">Shop now ></a>
			</div>
			<img src="assets/images/banners/4.jpg" alt="#" class="img-responsive">
		</div>
	</div><!-- /.item -->
	<div class="item">
		<div class="banner-outer">
			<div class="text">
				<h4>new design</h4>
				<h2>fashion</h2>
				<a class="shop-now" href="#">Shop now ></a>
			</div>
			<img src="assets/images/banners/4.jpg" alt="#" class="img-responsive">
		</div>
	</div><!-- /.item -->
</div><!-- /.banner-slider -->
<!-- ============================================== BANNER SLIDER : END ============================================== -->