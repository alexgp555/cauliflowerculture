<!-- ============================================== HAND TOOL-V3 BANNER-1X ============================================== -->
<div class="banner-1x-v3-hand-tool">
	<a href="#">
		<div class="image">
	        <img src="assets/images/banners/23.jpg" alt="#" class="img-responsive">
        </div>
		<div class="content">
			<span class="text-1">free</span>
			<span class="text-2">shipping</span>
			<span class="text-3">Order over $69</span>
		</div>	
    </a>
</div><!-- /.banner-1x-v3-hand-tool -->
<!-- ============================================== HAND TOOL-V3 BANNER-1X : END============================================== -->