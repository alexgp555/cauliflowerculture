<!-- ============================================== HAND TOOLS TAGS ============================================== -->
<div class="hand-tool-tag wow fadeIn" data-wow-delay="0.2s">
	<h3 class="section-title">Tags</h3>
	<div class="tag-list">					
		<a href="index.php?page=category-v2" title="Phone" class="item">Phone</a>
		<a href="index.php?page=category-v2" title="Vest" class="item active">Vest</a>
		<a href="index.php?page=category-v2" title="Smartphone" class="item">Smartphone</a>
		<a href="index.php?page=category-v2" title="Furniture" class="item">Furniture</a>
		<a href="index.php?page=category-v2" title="T-shirt" class="item">T-shirt</a>
		<a href="index.php?page=category-v2" title="Sweatpants" class="item">Sweatpants</a>
		<a href="index.php?page=category-v2" title="Sneaker" class="item">Sneaker</a>
		<a href="index.php?page=category-v2" title="Toys" class="item ">Toys</a>
		<a href="index.php?page=category-v2" title="Rose" class="item">Rose</a>
	</div>
</div><!-- /.hand-tool-tag -->
<!-- ============================================== HAND TOOLS TAGS : END ============================================== -->