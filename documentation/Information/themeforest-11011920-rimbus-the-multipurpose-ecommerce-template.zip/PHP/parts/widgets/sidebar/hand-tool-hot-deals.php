<!-- ============================================== HAND TOOL HOT DEALS ============================================== -->
<div class="product-item-small">
	<h3 class="section-title">hot deals</h3>
	<?php require RB_ROOT. '/parts/section/hand-tool/hand-tool-item-small.php'; ?>
</div><!-- /.product-item-small -->
<!-- ============================================== HAND TOOL HOT DEALS : END ============================================== -->