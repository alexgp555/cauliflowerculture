<!-- ============================================== GALLERY ============================================== -->
<div class="gallery wow fadeIn">
	<h3 class="section-title">gallery</h3>
	<ul class="list-unstyled">
		<li class=""><a href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/4.jpg" alt=""></a></li>
		<li class=""><a href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/5.jpg" alt=""></a></li>
		<li class="no-padding"><a href="index.php?page=blog-single"><img class="img-responsive " src="assets/images/blog/6.jpg" alt=""></a></li>
		<li class=""><a href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/7.jpg" alt=""></a></li>
		<li class=""><a href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/8.jpg" alt=""></a></li>
		<li class="no-padding"><a href="index.php?page=blog-single"><img class="img-responsive " src="assets/images/blog/9.jpg" alt=""></a></li>
	</ul>
</div><!-- /.gallery -->
<!-- ============================================== GALLERY : END ============================================== -->