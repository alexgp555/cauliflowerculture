<!-- ============================================== DIGITAL BY CATEGORY ============================================== -->
<div class="col-md-3">
	<div class="fashion-category">
		<h3 class="section-title">by category</h3>
		<div class="by-category">
			<ul>
				<li><a href="#">mobile <span class="item-count">(22)</span></a></li>
				<li><a href="#">computer <span class="item-count">(45)</span></a></li>
				<li><a href="#">laptop <span class="item-count">(29)</span></a></li>
				<li><a href="#">camera <span class="item-count">(41)</span></a></li>
				<li><a href="#">TV & Radio <span class="item-count">(58)</span></a></li>
				<li><a href="#">desktop <span class="item-count">(79)</span></a></li>
			</ul>
		</div>
	</div>
</div><!-- /.col -->
<!-- ============================================== DIGITAL BY CATEGORY : END ============================================== -->