<!-- ============================================== FOOD BY CATEGORY ============================================== -->
<div class="fashion-category">
	<div class="title">
		<h3>by category</h3>
		<hr>
	</div>
	<div class="by-category">
		<ul>
			<li><a href="#">desserts <span class="item-count">(22)</span></a></li>
			<li><a href="#">main dishes <span class="item-count">(45)</span></a></li>
			<li><a href="#">appetixers <span class="item-count">(29)</span></a></li>
			<li><a href="#">hot deals <span class="item-count">(41)</span></a></li>
			<li><a href="#">drink <span class="item-count">(58)</span></a></li>
			<li><a href="#">sale off <span class="item-count">(79)</span></a></li>
		</ul>
	</div><!-- /.by-category -->
</div><!-- /.fashion-category -->
<!-- ============================================== FOOD BY CATEGORY : END ============================================== -->
