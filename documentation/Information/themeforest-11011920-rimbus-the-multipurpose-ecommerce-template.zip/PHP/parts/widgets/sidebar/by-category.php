<!-- ============================================== BY CATEGORY ============================================== -->
<div class="fashion-category">
	<h3 class="section-title">by category</h3>
	<div class="by-category">
		<ul>
			<li><a href="#">Women <span class="item-count">(22)</span></a></li>
			<li><a href="#">men <span class="item-count">(45)</span></a></li>
			<li><a href="#">kids <span class="item-count">(29)</span></a></li>
			<li><a href="#">accessories <span class="item-count">(41)</span></a></li>
			<li><a href="#">dress <span class="item-count">(58)</span></a></li>
			<li><a href="#">Shoes <span class="item-count">(79)</span></a></li>
		</ul>
	</div>
</div><!-- /.fashion-category -->
<!-- ============================================== BY CATEGORY : END ============================================== -->