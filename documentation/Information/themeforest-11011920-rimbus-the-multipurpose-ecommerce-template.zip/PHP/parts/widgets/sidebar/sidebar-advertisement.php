<!-- ============================================== SIDEBAR ADVERTISEMENT ============================================== -->
<div class="sidebar-advertisment wow fadeIn" data-wow-delay="0.2s">
	<img class="img-responsive" src="assets/images/sliders/1.png" alt="">
	<div class="content-text">
		<span>new design</span>
		<h3>fashion</h3>
	</div>
</div><!-- /.sidebar-advertisment -->
<!-- ============================================== SIDEBAR ADVERTISEMENT : END ============================================== -->
