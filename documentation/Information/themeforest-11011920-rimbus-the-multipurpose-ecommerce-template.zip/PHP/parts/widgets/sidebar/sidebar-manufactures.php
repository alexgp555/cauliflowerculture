<!-- ============================================== SIDEBAR MANUFACTURES ============================================== -->
<div class="manufacture">
	<h4 class="sidebar-sub-title">manufacture</h4>
	<ul>
		<li><a href="#">Women <span class="item-count">(22)</span></a></li>
		<li><a href="#">men <span class="item-count">(45)</span></a></li>
		<li><a class="active" href="#">kids <span class="item-count">(29)</span></a></li>
		<li><a href="#">accessories <span class="item-count">(41)</span></a></li>
		<li><a href="#">dress <span class="item-count">(58)</span></a></li>
		<li><a href="#">Shoes <span class="item-count">(79)</span></a></li>
	</ul>
</div><!-- /.manufacture -->
<!-- ============================================== SIDEBAR MANUFACTURES : END ============================================== -->
