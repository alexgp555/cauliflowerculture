<!-- ============================================== PRODUCT HOT DEALS ============================================== -->
<div class="product-item-small hot-deals wow fadeIn" data-wow-delay="0.2s">
	<h3 class="section-title">hot deals</h3>
	<?php require RB_ROOT. '/parts/section/product-item-small.php'; ?>
</div><!-- /.product-item-small -->
<!-- ============================================== PRODUCT HOT DEALS : END ============================================== -->