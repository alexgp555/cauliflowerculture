<!-- ============================================== PRICE SILDER============================================== -->
<h4 class="sidebar-sub-title">price</h4>
<div class="sidebar-widget">
    <div class="sidebar-widget-body">
        <div class="price-range-holder">

            <input type="text" class="price-slider" value="" >

            <input type="text" class="price-input" value="60" > 
            <i class="fa fa-minus"></i>
            <input type="text" class="price-input" value="696" > 

            <a href="#">search</a>
   
        </div><!-- /.price-range-holder -->
    </div><!-- /.sidebar-widget-body -->
</div><!-- /.sidebar-widget -->
<!-- ============================================== PRICE SILDER : END ============================================== -->