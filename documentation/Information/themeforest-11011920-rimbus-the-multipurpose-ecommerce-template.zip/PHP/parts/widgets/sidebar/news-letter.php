<!-- ============================================== NEWSLETTER ============================================== -->
<div class="news-letter wow fadeIn" data-wow-delay="0.2s">
	<h3 class="section-title">Newsletter</h3>
	<h6>sign up to our newsletter</h6>
	<input type="text" class="email" placeholder="Enter your email">
	<button class="btn btn-primary">subscribe</button>
</div><!-- /.news-letter -->
<!-- ============================================== NEWSLETTER : END ============================================== -->