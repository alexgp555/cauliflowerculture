<!-- ============================================== HAND TOOL-V2 BANNER-1X ============================================== -->
<div class="banner-1x-v2-hand-tool outer-xs">
	<a href="#">
		<div class="image">
	        <img src="assets/images/banners/22.jpg" alt="#" class="img-responsive">
        </div>
		<div class="content">
			<span class="text-1">power tools</span>
			<span class="text-2">& accessories</span>
			<span class="text-3">Now Available</span>
		</div>	
    </a>
</div><!-- /.banner-1x-v2-hand-tool -->
<!-- ============================================== HAND TOOL-V2 BANNER-1X : END ============================================== -->