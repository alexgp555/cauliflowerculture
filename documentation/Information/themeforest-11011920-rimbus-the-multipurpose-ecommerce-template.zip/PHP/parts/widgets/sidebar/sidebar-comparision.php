<!-- ============================================== SIDEBAR COMPARISION ============================================== -->
<div class="compare">
	<h3 class="section-title">compare</h3>
	<ul>
		<li><a href="#">Product Name #01 <i class="fa fa-times-circle"></i></a></li>
		<li><a href="#">Product Name #02 <i class="fa fa-times-circle"></i></a></li>
	</ul>
</div><!-- /.compare -->
<!-- ============================================== SIDEBAR COMPARISION : END ============================================== -->
