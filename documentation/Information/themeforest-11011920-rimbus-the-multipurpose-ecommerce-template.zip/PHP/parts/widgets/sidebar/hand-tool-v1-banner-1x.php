<!-- ============================================== HAND TOOL-V1 BANNER-1X ============================================== -->
<div class="banner-1x-v1-hand-tool">
	<a href="#">
	    <div class="content"><h2>big sale!</h2><h1>50% off</h1><span class="action">Shop now</span></div>
	    <div class="image">
	        <img src="assets/images/banners/21.jpg" alt="#" class="img-responsive">
        </div>
    </a>
</div><!-- /.banner-1x-v1-hand-tool -->
<!-- ============================================== HAND TOOL-V1 BANNER-1X : END ============================================== -->