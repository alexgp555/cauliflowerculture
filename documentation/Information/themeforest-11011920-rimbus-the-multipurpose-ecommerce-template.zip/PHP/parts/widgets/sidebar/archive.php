<!-- ============================================== ARCHIVE ============================================== -->
<div class="archive wow fadeIn">
	<h3 class="section-title">archive</h3>
	<ul class="list-group">
	  <li class="list-group-item"><a href="#">September 2014</a></li>
	  <li class="list-group-item"><a href="#">August 2014</a></li>
	  <li class="list-group-item"><a href="#">July 2014</a></li>
	  <li class="list-group-item"><a href="#">October 2013</a></li>
	  <li class="list-group-item"><a href="#">January 2013</a></li>
	</ul>
</div><!-- /.archive -->
<!-- ============================================== ARCHIVE : END ============================================== -->