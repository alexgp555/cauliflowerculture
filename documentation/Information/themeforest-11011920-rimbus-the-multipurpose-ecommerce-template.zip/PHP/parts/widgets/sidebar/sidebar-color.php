<!-- ============================================== SIDEBAR COLOR ============================================== -->
<div class="color">
	<h4 class="sidebar-sub-title">color</h4>
	<ul>
		<li><a href="#">white <span class="item-count">(22)</span></a></li>
		<li><a href="#">Black <span class="item-count">(45)</span></a></li>
		<li><a class="" href="#">Pink <span class="item-count">(29)</span></a></li>
		<li><a href="#">Blue <span class="item-count">(87)</span></a></li>
		<li><a href="#">Yellow <span class="item-count">(52)</span></a></li>
		<li><a href="#">Red <span class="item-count">(14)</span></a></li>
	</ul>
</div><!-- /.color -->
<!-- ============================================== SIDEBAR COLOR : END ============================================== -->
