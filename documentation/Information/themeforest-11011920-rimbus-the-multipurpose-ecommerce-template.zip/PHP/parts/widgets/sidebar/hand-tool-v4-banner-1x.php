<!-- ============================================== HAND TOOL-V4 BANNER-1X ============================================== -->
<div class="single-banner outer-xs wow fadeIn" data-wow-delay="0.2s">
	<a href="#">
		<div class="image">
		    <img class="img-responsive" src="assets/images/banners/24.jpg" alt="#">
	    </div>
		<div class="content"><span class="line-1">sale 30%<span class="line-2">off</span></span></div>		
    </a>
</div><!-- /.single-banner -->
<!-- ============================================== HAND TOOL-V4 BANNER-1X : END ============================================== -->