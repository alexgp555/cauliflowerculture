<!-- ============================================== BLOG CATEGORY ============================================== -->
<div class="blog-category wow fadeIn">
	<h3 class="section-title">category</h3>
	<ul class="list-group">
	  <li class="list-group-item"><a href="#">Web Design</a></li>
	  <li class="list-group-item"><a href="#">PSD Template</a></li>
	  <li class="list-group-item"><a href="#">WordPress</a></li>
	  <li class="list-group-item"><a href="#">E-Commerce</a></li>
	  <li class="list-group-item"><a href="#">Magento</a></li>
	  <li class="list-group-item"><a href="#">Prestashop</a></li>
	</ul>
</div><!-- /.blog-category -->
<!-- ============================================== BLOG CATEGORY : END ============================================== -->