<!-- ============================================== NAVBAR ============================================== -->
<div class="header-nav animate-dropdown">
    <div class="yamm navbar navbar-default" role="navigation">
        <div class="nav-bg-class">
            <?php require RB_ROOT.'/parts/widgets/header/navbar-collapse-v1.php';?>
        </div><!-- /.nav-bg-class -->
    </div><!-- /.navbar-default -->
</div><!-- /.header-nav -->
<!-- ============================================== NAVBAR : END ============================================== -->