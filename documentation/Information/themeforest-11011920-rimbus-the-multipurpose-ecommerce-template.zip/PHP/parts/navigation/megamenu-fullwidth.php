<!-- ============================================== MEGA MENU FULL WIDTH ============================================== -->
<div class="yamm-content">
    <div class="row">
       <div class="col-xs-12 col-sm-4 col-md-4">
            <h2 class="title">Footwear</h2>
            <ul class="links">
                <li><a href="index.php?page=category-v1">Casual </a></li>
                <li><a href="index.php?page=category-v1">Sports </a></li>
                <li><a href="index.php?page=category-v1">Formal </a></li>
                <li><a href="index.php?page=category-v1">Sandals </a></li>
                <li><a href="index.php?page=category-v1">Sneakers</a></li>
                <li><a href="index.php?page=category-v1">Loafers</a></li>
            </ul>
        </div><!-- /.col -->

        <div class="col-xs-12 col-sm-4 col-md-4">
            <h2 class="title">Clothing</h2>
            <ul class="links">
                <li><a href="index.php?page=category-v1">T-Shirts</a></li>
                <li><a href="index.php?page=category-v1">Jeans</a></li>
                <li><a href="index.php?page=category-v1">Shirts</a></li>
                <li><a href="index.php?page=category-v1">Trousers</a></li>
                <li><a href="index.php?page=category-v1">Sleep Wear</a></li>
                <li><a href="index.php?page=category-v1">Cargos</a></li>
            </ul>
        </div><!-- /.col -->

        <div class="col-xs-12 col-sm-4 col-md-4">
            <h2 class="title">Watches</h2>
            <ul class="links">
                <li><a href="index.php?page=category-v1">Fastrack</a></li>
                <li><a href="index.php?page=category-v1">Casio</a></li>
                <li><a href="index.php?page=category-v1">Sonata</a></li>
                <li><a href="index.php?page=category-v1">Titan</a></li>
                <li><a href="index.php?page=category-v1">Maxima</a></li>
                <li><a href="index.php?page=category-v1">Timex</a></li>
            </ul>
        </div><!-- /.col -->
    </div><!-- /.row -->
</div><!-- /.yamm-content -->
<!-- ============================================== MEGA MENU FULL WIDTH : END ============================================== -->