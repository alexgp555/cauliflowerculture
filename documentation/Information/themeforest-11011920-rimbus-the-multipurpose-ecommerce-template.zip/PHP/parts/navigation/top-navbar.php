<!-- ============================================== TOP NAVBAR ============================================== -->
<div class="top-nav">
	<ul class="list-unstyled list-inline">
		<li class=""><a href="#">My Account</a></li>
		<li class="hidden-xs"><a href="#">Wishlist</a></li>
		<li class="hidden-xs"><a href="#">My Cart</a></li>
		<li class=""><a href="#">Checkout</a></li>
		<li class=""><a href="#">Login</a></li>
	</ul>
</div><!-- /.top-nav -->
<!-- ============================================== TOP NAVBAR : END ============================================== -->