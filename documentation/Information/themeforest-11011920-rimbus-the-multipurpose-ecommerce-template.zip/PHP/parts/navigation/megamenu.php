<!-- ============================================== MEGAMENU ============================================== -->
<div class="yamm-content">
    <div class="row">
        <div class="col-md-8 col-sm-8">
            <div class="row">
               <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Clothing</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Sarees</a></li>
                        <li><a href="index.php?page=category-v1">Kurta &amp; Kurti </a></li>
                        <li><a href="index.php?page=category-v1">Dress Materials</a></li>
                        <li><a href="index.php?page=category-v1">Salwar Kameez Sets</a></li>
                        <li><a href="index.php?page=category-v1">Dress sale</a></li>
                    </ul>
                </div><!-- /.col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">jewellery</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Rings</a></li>
                        <li><a href="index.php?page=category-v1">Earrings</a></li>
                        <li><a href="index.php?page=category-v1">Jewellery Sets </a></li>                
                        <li><a href="index.php?page=category-v1">Pendants &amp; Lockets</a></li>
                        <li><a href="index.php?page=category-v1">plastic Jewellery</a></li>
                    </ul>
                </div><!-- /.col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Beauty</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Make Up</a></li>
                        <li><a href="index.php?page=category-v1">Hair Care</a></li>
                        <li><a href="index.php?page=category-v1">Deodorants</a></li>
                        <li><a href="index.php?page=category-v1">Bath &amp; Body </a></li>
                        <li><a href="index.php?page=category-v1">skin care</a></li>                                       
                    </ul>
                </div><!-- /.col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Watches</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Fastrack </a></li> 
                        <li><a href="index.php?page=category-v1">Timex</a></li>
                        <li><a href="index.php?page=category-v1">Titan</a></li>
                        <li><a href="index.php?page=category-v1">Fossil</a></li>
                        <li><a href="index.php?page=category-v1">casio</a></li>
                    </ul>
                </div><!-- /.col -->
            </div><!-- /.row -->


            <div class="row">
               <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Footwear</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Flats</a></li>
                        <li><a href="index.php?page=category-v1">Heels </a></li>
                        <li><a href="index.php?page=category-v1">Boots</a></li>
                        <li><a href="index.php?page=category-v1">Slippers</a></li>
                        <li><a href="index.php?page=category-v1">shoes</a></li>
                    </ul>
                </div><!-- /.col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Western Wear</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Jeans</a></li>
                        <li><a href="index.php?page=category-v1">Polo's &amp; T-Shirts</a></li>
                        <li><a href="index.php?page=category-v1">Shirts Tops  </a></li>                   
                        <li><a href="index.php?page=category-v1">Gymwear</a></li>
                        <li><a href="index.php?page=category-v1">Sleep Wear</a></li>
                    </ul>
                </div><!-- /.col -->

                <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Bags &amp; Wallets</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Handbags</a></li>
                        <li><a href="index.php?page=category-v1">Sling Bags</a></li>
                        <li><a href="index.php?page=category-v1">Wallets &amp; Belts</a></li>
                        <li><a href="index.php?page=category-v1">Totes </a></li>
                        <li><a href="index.php?page=category-v1">travel Bags</a></li>                                       
                    </ul>
                </div><!-- /.col -->

                 <div class="col-xs-12 col-sm-6 col-md-3">
                    <h2 class="title">Sunglasses</h2>
                    <ul class="links">
                        <li><a href="index.php?page=category-v1">Over-sized </a></li> 
                        <li><a href="index.php?page=category-v1">Wayfarer</a></li>
                        <li><a href="index.php?page=category-v1">Premium Brands</a></li>
                        <li><a href="index.php?page=category-v1">UV glass</a></li>
                        <li><a href="index.php?page=category-v1">colores</a></li>
                    </ul>
                </div><!-- /.col -->
            </div><!-- /.col -->
        </div><!-- /.col -->

        <div class="col-sm-4 col-md-4">
            <div class="menu-banner">
                <img class="img-responsive" src="assets/images/banners/9.jpg" alt="R">
                <span class="line"></span>
                <div class="content">
                    <span class="text text-1">collection</span>
                    <span class="text text-2">women's</span>
                    <span class="text text-3">save up to 25% off</span>
                </div><!-- /.content -->
            </div><!-- /.menu-banner -->
        </div><!-- /.col -->
    </div><!-- /.row -->
</div><!-- /.yamm-content -->
<!-- ============================================== MEGAMENU : END ============================================== -->
