<!-- ================================== MEGAMENU VERTICAL ================================== -->
<ul class="dropdown-menu mega-menu image">
    <li>
        <div class="yamm-content">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-lg-7">

                    <div class="col-xs-12 col-sm-12 col-lg-4">
                        <h2 class="title">Clothing</h2>
                        <ul class="links list-unstyled">
                            <li><a href="#">Floral Print</a></li>
                            <li><a href="#">Bags</a></li>
                            <li><a href="#">Boots</a></li>
                            <li><a href="#">Jackets</a></li>
                            <li><a href="#">Jeans</a></li>
                            <li><a href="#">Bottoms</a></li>
                            <li><a href="#">T-Shirts</a></li>
                            <li><a href="#">Sneakers</a></li>
                        </ul>
                    </div><!-- /.col -->

                    <div class="col-xs-12 col-sm-12 col-lg-4">
                        <h2 class="title">footwear</h2>
                        <ul class="links list-unstyled">
                            <li><a href="#">Dresses</a></li>
                            <li><a href="#">Hats</a></li>
                            <li><a href="#">Jackets</a></li>
                            <li><a href="#">Bottoms</a></li>
                            <li><a href="#">T-Shirts</a></li>
                            <li><a href="#">Jeans</a></li>
                            <li><a href="#">Hats</a></li>
                            <li><a href="#">Boots</a></li>
                        </ul>
                    </div><!-- /.col -->

                    <div class="col-xs-12 col-sm-12 col-lg-4">
                        <h2 class="title">health</h2>
                        <ul class="links list-unstyled">
                            <li><a href="#">Floral Print</a></li>
                            <li><a href="#">Bags</a></li>
                            <li><a href="#">Boots</a></li>
                            <li><a href="#">Jackets</a></li>
                            <li><a href="#">Jeans</a></li>
                            <li><a href="#">Bottoms</a></li>
                            <li><a href="#">T-Shirts</a></li>
                            <li><a href="#">Sneakers</a></li>
                        </ul>
                    </div><!-- /.col -->
                    
                </div><!-- /.col -->
                

                <div class="col-xs-12 col-sm-12 col-lg-5 dropdown-banner">
                    <a  href="#"><span></span><img class="img-responsive"  src="assets/images/banners/9.jpg" alt=""></a>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.yamm-content -->   
    </li>                 
</ul><!-- /.dropdown-menu -->
<!-- ================================== MEGAMENU VERTICAL ================================== --> 