<!-- ============================================== NORMAL MENU ============================================== -->
<ul class="dropdown-menu mega-menu normal">
    <li>
        <div class="yamm-content">
            <div class="row">
                <div class="col-sm-12 col-md-3">
                    <h2 class="title">computer</h2>
                    <ul class="links list-unstyled">  
                        <li><a href="index.php?page=category">Lenovo</a></li>
                        <li><a href="index.php?page=category">Microsoft</a></li>    
                        <li><a href="index.php?page=category">Fuhlen</a></li>                                        
                        <li><a href="index.php?page=category">Longsleeves</a></li>    
                    </ul>
                </div><!-- /.col -->
                <div class="col-sm-12 col-md-3">
                    <h2 class="title">laptop</h2>
                    <ul class="links list-unstyled">
                        <li><a href="index.php?page=category">Microsoft</a></li>
                        <li><a href="index.php?page=category">Apple</a></li>    
                        <li><a href="index.php?page=category">Tees &amp; Tanks</a></li>                                        
                        <li><a href="index.php?page=category">Graphic Tees</a></li>  
                    </ul>
                </div><!-- /.col -->
                <div class="col-sm-12 col-md-3">
                    <h2 class="title">camera</h2>
                    <ul class="links list-unstyled">
                        <li><a href="index.php?page=category">Polos</a></li>
                        <li><a href="index.php?page=category">Sweaters</a></li>    
                        <li><a href="index.php?page=category">Shirts</a></li>                                        
                        <li><a href="index.php?page=category">Hoodies</a></li>  
                    </ul>
                </div><!-- /.col -->
                <div class="col-sm-12 col-md-3">
                    <h2 class="title">watch</h2>
                    <ul class="links list-unstyled">
                        <li><a href="index.php?page=category">Microsoft</a></li>
                        <li><a href="index.php?page=category">Apple</a></li>    
                        <li><a href="index.php?page=category">Tees &amp; Tanks</a></li>                                        
                        <li><a href="index.php?page=category">Graphic Tees</a></li>  
                    </ul>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.yamm-content -->  
    </li>                  
</ul><!-- /.dropdown-menu -->   
<!-- ============================================== NORMAL MENU : END ============================================== -->