<!-- ============================================== BOX BANNER MINI ============================================== -->
<div class="banner-6x4 wow fadeInUp">
	<div class="col-md-8 col-sm-12 banner-1 wow fadeInUp" data-wow-delay="0.2s">
		<div class="banner-outer">
			<a href="#">
				<div class="image">
					<img src="assets/images/banners/35.jpg" alt="#" class="img-responsive">
				</div>
				<div class="text">
					<span>new trends</span>
					<h2>street fashion</h2>
					<h4>develop by anas from chennai</h4>
				</div>				
			</a>
		</div><!-- /.banner-outer -->
	</div><!-- /.col -->
	
	<div class="col-md-4 col-sm-12 banner-2 wow fadeInUp" data-wow-delay="0.4s">
		<div class="banner-outer">
			<a href="#">
				<div class="image">
					<img src="assets/images/banners/14.jpg" alt="#" class="img-responsive">
				</div>
				<div class="text">
					<span>free</span>
					<h2>shipping</h2>
					<h4>on all order in your cart</h4>
				</div>			
			</a>
		</div><!-- /.banner-outer -->
	</div><!-- /.col -->
</div><!-- /.banner-6x4 -->
<!-- ============================================== BOX BANNER MINI : END ============================================== -->