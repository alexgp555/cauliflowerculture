<!-- ============================================== NEWSLETTER-X2 ============================================== -->
<div class="newsletter-outer outer-top-sm wow fadeInUp"  style="background-image: url(assets/images/testimonial/5.jpg);">
	<div class="top-wrapper"></div>
	<div class="newsletter-x2">
		<div class="container">
			<div class="letter-outer">
				<div class="title">
					<h3>news letter</h3>
					<hr>
				</div><!-- /.title -->
				<div class="content">
					<p>Consectetur adipisicing elit se do eiusm od tempor incididunt ut labore et dolore magnas aliqua.</p>
				</div><!-- /.content -->
				<div class="input-group">
			    	<input type="text" class="form-control" placeholder="enter your email ">
			    	<span class="input-group-btn">
			      		<button class="btn btn-default" type="button"><i class="fa fa-arrow-circle-o-right"></i></button>
			    	</span>
			    </div><!-- /.input-group -->
			</div><!-- /.letter-outer -->
		</div><!-- /.container -->
	</div><!-- /.newsletter-x2 -->
</div><!-- /.newsletter-outer -->
<!-- ============================================== NEWSLETTER-X2 : END ============================================== -->