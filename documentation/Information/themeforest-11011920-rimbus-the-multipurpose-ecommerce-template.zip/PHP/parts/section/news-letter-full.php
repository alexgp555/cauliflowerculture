<!-- ============================================== NEWSLETTER FULL ============================================== -->
<div class="full-letter outer-top-xs wow fadeInUp ">
	<div class="container">
		<div class="row news-letter-full">

			<div class="col-md-4 col-sm-4">
				<div class="text">
					<h4>newsletter</h4>
					<span>sign up to our newsletter</span>
					<img src="assets/images/newsletter/1.png" alt="" class="img-responsive">
				</div>
			</div><!-- /.col -->

			<div class="col-md-6 col-sm-7 input-email">
				<div class="input-group">
			    	<input type="text" class="form-control" placeholder="Enter your email">
			    	<span class="input-group-btn">
			        	<button class="btn btn-primary" type="button">Subscribe</button>
			    	</span>
			    </div><!-- /input-group -->

				<img src="assets/images/newsletter/2.png" alt="" class="img-responsive">
			</div><!-- /.col -->
			
		</div><!-- /.row -->
	</div><!-- /.container -->
</div><!-- /.full-letter -->
<!-- ============================================== NEWSLETTER FULL : END ============================================== -->