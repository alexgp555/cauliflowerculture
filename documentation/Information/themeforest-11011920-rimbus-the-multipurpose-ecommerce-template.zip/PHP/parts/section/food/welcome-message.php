<!-- ========================================== WELCOME MESSAGE ========================================= -->
<div class="welcome-message animated fadeIn">
	<h3>welcome to our <span class="logo-first">rim</span><span class="logo-color">bus</span></h3>
	<hr>
	<p>Donec mollis malesuada lorem, ac lacinia nisl. Ut varius mattis ipsum, non fringilla lorem dictum eget. Vestibulum et consequat libero. Aliquam aliquam enim in nibh maximus.</p>
</div><!-- /.welcome-message -->
<!-- ========================================== WELCOME MESSAGE : END ========================================= -->