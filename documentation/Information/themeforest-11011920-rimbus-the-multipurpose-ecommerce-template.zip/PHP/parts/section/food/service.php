<!-- ========================================== SERVICE ========================================= -->
<div class="service wow fadeInUp">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.2s">
				<a href="#">
					<div class="content-box">
						<div class="icon-outer"><div class="icon"><i class="fa fa-coffee"></i></div></div>
						<h4>Breakfast Menu</h4>
						<p>Donec mollis malesuada lorem, ac lacinia nisl. Ut varius mattis ipsum, non fringilla lorem.</p>
					</div>
				</a>
			</div><!-- /.col -->
			<div class="col-md-4 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.4s">
				<a href="#">
					<div class="content-box">
						<div class="icon-outer"><div class="icon"><i class="fa fa-cutlery"></i></div></div>
						<h4>lunch Menu</h4>
						<p>Donec mollis malesuada lorem, ac lacinia nisl. Ut varius mattis ipsum, non fringilla lorem.</p>
					</div>
				</a>
			</div><!-- /.col -->
			<div class="col-md-4 col-sm-12 col-xs-12 wow fadeInUp" data-wow-delay="0.6s">
				<a href="#">
					<div class="content-box">
						<div class="icon-outer"><div class="icon"><i class="fa fa-beer"></i></div></div>
						<h4>dinner Menu</h4>
						<p>Donec mollis malesuada lorem, ac lacinia nisl. Ut varius mattis ipsum, non fringilla lorem.</p>
					</div>
				</a>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container -->
</div><!-- /.service -->
<!-- ========================================== SERVICE : END ========================================= -->