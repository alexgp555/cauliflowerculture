<!-- ========================================== TESTIMONIAL ========================================= -->
<div class="testimonial-outer outer-top-sm wow fadeInUp"  style="background-image: url(assets/images/testimonial/4.jpg);">
	<div class="top-wrapper"></div>
	<div class="testimonial" id="client-testimonial">
		<div class="item">
			<div class="container">
				<div class="comment-outer">
					<div class="content">
						<div class="icon">
							<i class="fa fa-quote-left"></i>
						</div>
						<p>“  Curabitur sed sem at eros porttids torCura bitur sed sem at eros portCurabitur sed sem at eros portt. Curabitur sed ses  sat eros porttids tor.Curabitur sed ses  sat eros porttids tor ”</p>
					</div>
					<div class="media">
						<div class="media-left">
							<a href="#">
								<img class="media-object img-responsive" src="assets/images/testimonial/2.jpg" alt="clinet">
							</a>
						</div>
						<div class="media-body">
							<h4 class="media-heading">Mohamed Anas</h4>
							<span>CEO-Rimbus</span>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item">
			<div class="container">
				<div class="comment-outer">
					<div class="content">
						<div class="icon">
							<i class="fa fa-quote-left"></i>
						</div>
						<p>“  Curabitur sed sem at eros porttids torCura bitur sed sem at eros portCurabitur sed sem at eros portt. Curabitur sed ses  sat eros porttids tor.Curabitur sed ses  sat eros porttids tor ”</p>
					</div>
					<div class="media">
						<div class="media-left">
							<a href="#">
								<img class="media-object img-responsive" src="assets/images/testimonial/3.jpg" alt="clinet">
							</a>
						</div>
						<div class="media-body">
							<h4 class="media-heading">Mohamed Anas</h4>
							<span>CEO-Rimbus</span>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item">
			<div class="container">
				<div class="comment-outer">
					<div class="content">
						<div class="icon">
							<i class="fa fa-quote-left"></i>
						</div>
						<p>“  Curabitur sed sem at eros porttids torCura bitur sed sem at eros portCurabitur sed sem at eros portt. Curabitur sed ses  sat eros porttids tor.Curabitur sed ses  sat eros porttids tor ”</p>
					</div>
					<div class="media">
						<div class="media-left">
							<a href="#">
								<img class="media-object img-responsive" src="assets/images/testimonial/3.jpg" alt="clinet">
							</a>
						</div>
						<div class="media-body">
							<h4 class="media-heading">Mohamed Anas</h4>
							<span>CEO-Rimbus</span>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /.item -->

	</div><!-- /.testimonial -->
</div><!-- /.testimonial-outer -->
<!-- ========================================== TESTIMONIAL : END ========================================= -->