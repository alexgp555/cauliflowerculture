<!-- ========================================== SECTION – HERO ========================================= -->
<div class="food-slider hero-style-2" id="hero">
	<div class="big-slider owl-main owl-carousel owl-inner-nav owl-ui-lg" id="owl-main">
		<div class="item" style="background-image: url(assets/images/sliders/7.jpg);">
			<div class="container">
				<div class="slider caption vertical-center text-right">
					<h2 class="fadeInDown-1">get gift card</h2>
					<h1 class="fadeInDown-2">drink <span>&amp;food</span></h1>
					<div class="slide-btn fadeInDown-3">
						<a href="#" class="btn btn-primary">Shop Now</a>
					</div>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item" style="background-image: url(assets/images/sliders/7.jpg);">
			<div class="container">
				<div class="slider caption vertical-center text-right">
					<h2 class="fadeInDown-1">get gift card</h2>
					<h1 class="fadeInDown-2">drink <span>&amp;food</span></h1>
					<div class="slide-btn fadeInDown-3">
						<a href="#" class="btn btn-primary">Shop Now</a>
					</div>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item" style="background-image: url(assets/images/sliders/7.jpg);">
			<div class="container">
				<div class="slider caption vertical-center text-right">
					<h2 class="fadeInDown-1">get gift card</h2>
					<h1 class="fadeInDown-2">drink <span>&amp;food</span></h1>
					<div class="slide-btn fadeInDown-3">
						<a href="#" class="btn btn-primary">Shop Now</a>
					</div>
				</div>
			</div>
		</div><!-- /.item -->
	</div><!-- /.big-slider -->
</div><!-- /.food-slider -->
<!-- ========================================= SECTION – HERO : END ========================================= -->