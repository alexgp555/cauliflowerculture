<!-- ============================================== OUR BRANDS-V2 ============================================== -->
<div class="col-md-12 outer-top-small wow fadeInUp">
	<h3 class="section-title">our brands</h3>
	<div class="our-brands-v2">
		<div class="item wow fadeInUp" data-wow-delay="0.2s"><a href="#" class="logo"><img src="assets/images/brands/6.png" alt="#" class=""></a></div>
		<div class="item wow fadeInUp" data-wow-delay="0.4s"><a href="#" class="logo"><img src="assets/images/brands/7.png" alt="#" class=""></a></div>
		<div class="item wow fadeInUp" data-wow-delay="0.6s"><a href="#" class="logo"><img src="assets/images/brands/8.png" alt="#" class=""></a></div>
		<div class="item wow fadeInUp" data-wow-delay="0.8s"><a href="#" class="logo"><img src="assets/images/brands/9.png" alt="#" class=""></a></div>
		<div class="item wow fadeInUp" data-wow-delay="1s"><a href="#" class="logo"><img src="assets/images/brands/10.png" alt="#" class=""></a></div>
		<div class="item wow fadeInUp" data-wow-delay="1.2s"><a href="#" class="logo"><img src="assets/images/brands/11.png" alt="#" class=""></a></div>
	</div><!-- /.our-brands-v2 -->
</div><!-- /.col -->
<!-- ============================================== OUR BRANDS-V2 : END ============================================== -->