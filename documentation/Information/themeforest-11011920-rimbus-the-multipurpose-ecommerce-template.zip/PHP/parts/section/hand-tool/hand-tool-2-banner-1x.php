<!-- ========================================== HAND TOOL-2 BANNER-1X ========================================= -->
<div class="hand-2-banner-1x outer-bottom-xs wow fadeInUp">
	<div class="banner-full">
		<a href="#">
			<div class="image">
				<img src="assets/images/banners/20.jpg" alt="#" class="img-responsive">
			</div>
			<div class="content">
				<h3>Bestter Price!</h3>
				<h1>Bestter Tools.</h1>
			</div>		
	    </a>
	</div><!-- /.banner-full -->
</div><!-- /.hand-2-banner-1x -->
<!-- ========================================== HAND TOOL-2 BANNER-1X : END ========================================= -->