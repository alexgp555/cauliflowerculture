<!-- ========================================== HAND TOOL SLIDER ========================================= -->
<div class="hand-tool hero-style-4" id="hero">
	<div class="sliders owl-main owl-carousel owl-inner-nav owl-ui-lg" id="owl-main">
		<div class="item" style="background-image: url(assets/images/sliders/10.jpg);">
			<div class="slider-outer">
				<div class="content caption vertical-center text-left">
					<h4 class="fadeInLeft-1">collection</h4>
					<h2 class="fadeInLeft-2">sale off</h2>
					<h6 class="fadeInLeft-3 hidden-xs">save up to 25% for all!</h6>
					<a class="btn btn-primary fadeInLeft-4">shop now</a>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item" style="background-image: url(assets/images/sliders/10.jpg);">
			<div class="slider-outer">
				<div class="content caption vertical-center text-left">
					<h4 class="fadeInDown-1">collection</h4>
					<h2 class="fadeInDown-2">sale off</h2>
					<h6 class="fadeInDown-3 hidden-xs">save up to 25% for all!</h6>
					<a class="btn btn-primary fadeInDown-4">shop now</a>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item" style="background-image: url(assets/images/sliders/10.jpg);">
			<div class="slider-outer">
				<div class="content caption vertical-center text-left">
					<h4 class="fadeInLeft-1">collection</h4>
					<h2 class="fadeInLeft-2">sale off</h2>
					<h6 class="fadeInLeft-3 hidden-xs">save up to 25% for all!</h6>
					<a class="btn btn-primary fadeInLeft-4">shop now</a>
				</div>
			</div>
		</div><!-- /.item -->
	</div><!-- /.sliders -->
</div><!-- /.hand-tool -->
<!-- ========================================== HAND TOOL SLIDER : END ========================================= -->