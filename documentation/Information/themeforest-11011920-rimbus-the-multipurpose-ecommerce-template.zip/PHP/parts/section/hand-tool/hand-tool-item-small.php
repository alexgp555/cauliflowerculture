<!-- ==========================================HAND TOOL ITEM SMALL ========================================= -->
<div class="product-item-small-owl">
	<div class="item">
		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/60.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
				
			</div>
			
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/61.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/62.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/63.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>
	</div>

	<div class="item">
		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/63.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/62.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/61.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/60.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>
	</div>

	<div class="item">
		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/60.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
				
			</div>
			
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/61.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/62.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="row products-small">
			<div class="col-md-4 col-xs-4 product-image">
				<a href="#"><img src="assets/images/products/63.jpg" class="img-responsive" alt="">
					<div class="hover">
						<div class="hover-outer">
							<span class="hover-icon"><span><i class="fa fa-search"></i></span></span>
						</div>
					</div>
				</a>
			</div>
			<div class="col-md-8 col-xs-8 product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>
	</div>

</div>
<!-- ========================================== HAND TOOL ITEM SMALL : END ========================================= -->