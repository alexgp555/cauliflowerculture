<!-- ========================================== HAND TOOL BANNER-1X ========================================= -->
<div class="hand-banner-1x outer-bottom-xs wow fadeInUp">
	<div class="banner-full">
		<a href="#">
			<div class="image">
				<img src="assets/images/banners/19.jpg" alt="#" class="img-responsive">
			</div>
			<div class="content">
				<h1>What you need?</h1>
				<h3>when you need it?</h3>
			</div>
		</a>
	</div>
</div>
<!-- ========================================== HAND TOOL BANNER-1X : END ========================================= -->