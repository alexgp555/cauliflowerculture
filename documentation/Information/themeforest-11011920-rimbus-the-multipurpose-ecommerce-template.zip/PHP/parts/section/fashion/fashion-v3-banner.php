<!-- ============================================== FASHION-V3 BANNER ============================================== -->
<div class="container banner-link wow fadeInUp">
	<div class="row">
		<div class="col-md-4 col-sm-6 banner-1">			
			<div class="banner-outer">	
				<a href="#">		
					<div class="text">
						<h2>accessories</h2>
						<h4>new arrivals</h4>
						<span class='shop-now'>Shop now </span>
					</div>
					<div class="image">
						<img src="assets/images/banners/1.png" class="img-responsive" alt="#">	
					</div>
				</a>			
			</div>
			
		</div><!-- /.col -->

		<div class="col-md-4 col-sm-6 banner-2">
			<div class="banner-outer ">
				<a href="#">		
				<div class="text">
					<h4>fashion 2015</h4>
					<h2>lookbook</h2>
					<span class='shop-now'>Shop now </span>
				</div>
				<div class="image">
				     <img src="assets/images/banners/3.jpg" alt="#" class="img-responsive">
				</div>
				</a>
			</div>		
		</div><!-- /.col -->

		<div class="col-md-4 col-sm-12 banner-3">
			<div class="banner-outer">
				<a href="#">
					<div class="text">
						<h4>new design</h4>
						<h2>fashion</h2>
						<span class='shop-now'>Shop now </span>
					</div>
					<div class="image">
					     <img src="assets/images/banners/2.jpg" alt="#" class="img-responsive">
					</div>
				</a>
			</div>			
		</div><!-- /.col -->
	</div><!-- /.row -->
</div><!-- /.container -->

<!-- ============================================== FASHION-V3 BANNER : END ============================================== -->