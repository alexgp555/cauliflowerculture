<!-- ============================================== PRODUCT SLIDER ============================================== -->
<div class="row">
	<div class="col-md-4 wow fadeInUp" data-wow-delay="0.2s">
		<?php require RB_ROOT. '/parts/section/fashion/product-special-offer.php'; ?>
	</div><!-- /.col -->
	<div class="col-md-4 wow fadeInUp" data-wow-delay="0.4s">
		<?php require RB_ROOT. '/parts/section/fashion/product-new-arrivals.php'; ?>
	</div><!-- /.col -->
	<div class="col-md-4 wow fadeInUp" data-wow-delay="0.6s">
		<?php require RB_ROOT. '/parts/section/fashion/product-best-seller.php'; ?>
	</div><!-- /.col -->
</div><!-- /.row -->
<!-- ============================================== PRODUCT SLIDER : END ============================================== -->