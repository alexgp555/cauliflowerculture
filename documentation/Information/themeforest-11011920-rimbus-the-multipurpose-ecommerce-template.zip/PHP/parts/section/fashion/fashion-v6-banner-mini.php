<!-- ============================================== FASHION-V6 BANNER MINI============================================== -->
<div class="banner-6x4 wow fadeInUp">
	<div class="row">
		<div class="col-md-8 banner-1 wow fadeInUp" data-wow-delay="0.2s">
			<div class="banner-outer">
				<a href="#">
					<div class="image">
						<img src="assets/images/banners/13.jpg" alt="#" class="img-responsive">
					</div>
					<div class="text">
						<span>new trends</span>
						<h2>street fashion</h2>
						<h4>develop by anas from chennai</h4>
					</div>
				</a>
			</div>
		</div><!-- /.col -->
		
		<div class="col-md-4 banner-2 wow fadeInUp" data-wow-delay="0.4s">
			<div class="banner-outer">
				<a href="#">
					<div class="text">
						<span>free</span>
						<h2>shipping</h2>
						<h4>on all order in your cart</h4>
					</div>
					<div class="image">
					    <img src="assets/images/banners/14.jpg" class="img-responsive" alt="#">
					</div>
				</a>
			</div>
		</div><!-- /.col -->
	</div><!-- /.row -->
</div><!-- /.banner-6x4 -->
<!-- ============================================== FASHION-V6 BANNER MINI : END ============================================== -->