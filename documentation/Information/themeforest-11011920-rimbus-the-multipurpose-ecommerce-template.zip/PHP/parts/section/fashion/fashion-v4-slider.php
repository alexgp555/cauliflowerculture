<!-- ========================================== SECTION – HERO ========================================= -->
<div class="fashion-v4-slider hero-style-1" id="hero">
	<div class="big-slider owl-main owl-carousel owl-inner-nav owl-ui-lg" id="owl-main">
		<div class="slider-2 item" style="background-image: url(assets/images/sliders/5.jpg);">
			<div class="container">
				<div class="caption vertical-center text-right">
					<div class="slide-text-2">
						<h2 class="fadeInLeft-1">collection</h2>
						<h1 class="fadeInLeft-2">sale off</h1>
						<p class="fadeInLeft-3">Save up to 25% for all in your order! </p>
						<a href="#" class="btn btn-primary fadeInLeft-4">Shop Now</a>
						
					</div>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="slider-2 item" style="background-image: url(assets/images/sliders/5.jpg);">
			<div class="container">
				<div class="caption vertical-center text-right">
					<div class="slide-text-2">
						<h2 class="fadeInLeft-1">collection</h2>
						<h1 class="fadeInLeft-2">sale off</h1>
						<p class="fadeInLeft-3">Save up to 25% for all in your order! </p>
						<a href="#" class="btn btn-primary fadeInLeft-4">Shop Now</a>
						
					</div>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="slider-2 item" style="background-image: url(assets/images/sliders/5.jpg);">
			<div class="container">
				<div class="caption vertical-center text-right">
					<div class="slide-text-2">
						<h2 class="fadeInLeft-1">collection</h2>
						<h1 class="fadeInLeft-2">sale off</h1>
						<p class="fadeInLeft-3">Save up to 25% for all in your order! </p>
						<a href="#" class="btn btn-primary fadeInLeft-4">Shop Now</a>
						
					</div>
				</div>
			</div>
		</div><!-- /.item -->
	</div><!-- /.big-slider -->
</div><!-- /.fashion-v4-slider -->
<!-- ========================================= SECTION – HERO : END ========================================= -->