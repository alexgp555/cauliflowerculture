<!-- ============================================== FASHION-V4 BANNER-2X ============================================== -->
<div class="banner-2x row outer-xs wow fadeInUp">
	<div class="col-md-7 col-sm-6 col-xs12 wow fadeInUp" data-wow-delay="0.2s">
		<div class="banner">
			<a href="#">
				<div class="banner-1">
					<div class="image">
					    <img src="assets/images/banners/5.jpg" alt="#" class="img-responsive">
					</div>
					<div class="content">
						<h3>street fashion</h3>
						<span>new trends</span>
					</div>
					
				</div>
			</a>
		</div>
	</div><!-- /.col -->
	<div class="col-md-5 col-sm-6 col-xs12 wow fadeInUp" data-wow-delay="0.4s">
		<div class="banner">
			<a href="#">
				<div class="banner-2">
					<div class="image">
					    <img src="assets/images/banners/6.jpg" alt="#" class="img-responsive">
					</div>
					<div class="content">
						<span>free</span>
						<h2>shipping</h2>
						<span>on all order in cart</span>
					</div>
					
				</div>
			</a>
		</div>
	</div><!-- /.col -->
</div><!-- /.banner-2x -->
<!-- ============================================== FASHION-V4 BANNER-2X : END ============================================== -->