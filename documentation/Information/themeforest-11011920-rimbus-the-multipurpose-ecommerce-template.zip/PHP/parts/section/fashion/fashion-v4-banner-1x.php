<!-- ============================================== FASHION-V4 BANNER-1X ============================================== -->
<div class="banner-1x outer-xs wow fadeInUp">
	<div class="banner-full">
		<a href="#">
			<div class="image">
				<img src="assets/images/banners/7.jpg" alt="#" class="img-responsive">
			</div><!-- /.image -->
			<div class="content">
				<span>black friday sale <br>extra 30% off sale items</span>
			</div><!-- /.content -->

		</a>
	</div><!-- /.banner-full -->
</div><!-- /.banner-1x -->
<!-- ============================================== FASHION-V4 BANNER-1X : END ============================================== -->