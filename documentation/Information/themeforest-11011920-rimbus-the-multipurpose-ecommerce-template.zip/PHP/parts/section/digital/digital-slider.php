<!-- ============================================== DIGITAL SLIDER ============================================== -->
<div class="digital hero-style-1" id="hero">
	<div class="sliders owl-main owl-carousel owl-inner-nav owl-ui-lg" id="owl-main">
		<div class="item" style="background-image: url(assets/images/sliders/8.jpg);">
			<div class="slider-outer">
				<div class="content caption vertical-center text-right">
					<h2 class="fadeInRight-1">i phone 6+</h2>
					<h4 class="fadeInRight-2 hidden-xs">biger than biger</h4>
					<ul class="fadeInRight-3 hidden-xs items">
						<li>4.7/5.5 inches</li>
						<li>Iphone at its largest</li>
						<li>a better display</li>
						<li>hugely powerful</li>
						<li>more and more</li>
					</ul>
					<a class="btn btn-primary fadeInRight-4">shop now</a>
				</div>
			</div>
		</div><!-- /.item -->

		<div class="item" style="background-image: url(assets/images/sliders/8.jpg);">
			<div class="slider-outer">
				<div class="content caption vertical-center text-right">
					<h2 class="fadeInDown-1">i phone 6+</h2>
					<h4 class="fadeInDown-2 hidden-xs">biger than biger</h4>
					<ul class="fadeInDown-3 hidden-xs items">
						<li>4.7/5.5 inches</li>
						<li>Iphone at its largest</li>
						<li>a better display</li>
						<li>hugely powerful</li>
						<li>more and more</li>
					</ul>
					<a class="btn btn-primary fadeInDown-4">shop now</a>
				</div>
			</div>
		</div><!-- /.item -->

		<div class="item" style="background-image: url(assets/images/sliders/8.jpg);">
			<div class="slider-outer">
				<div class="content caption vertical-center text-right">
					<h2 class="fadeInLeft-1">i phone 6+</h2>
					<h4 class="fadeInLeft-2 hidden-xs">biger than biger</h4>
					<ul class="fadeInLeft-3 hidden-xs items">
						<li>4.7/5.5 inches</li>
						<li>Iphone at its largest</li>
						<li>a better display</li>
						<li>hugely powerful</li>
						<li>more and more</li>
					</ul>
					<a class="btn btn-primary fadeInLeft-4">shop now</a>
				</div>
			</div>
		</div><!-- /.item -->
	</div><!-- /.sliders -->
</div><!-- /.digital -->
<!-- ============================================== DIGITAL SLIDER : END ============================================== -->
