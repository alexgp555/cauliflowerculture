<!-- ============================================== DIGITAL BEST SELLER ============================================== -->
<div class="product-item-small">
	<h3 class="section-title">best seller</h3>
	<div class="product-item-small-owl">
		<div class="item">
			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/51.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>

			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/52.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>

			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/53.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>
		</div><!-- /.item -->

		<div class="item">
			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/53.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>

			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/51.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>

			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/52.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>
		</div><!-- /.item -->

		<div class="item">
			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/51.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>

			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/53.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>

			<div class="row products-small">
				<div class="col-md-4 col-xs-4 product-image">
					<a href="#"><img src="assets/images/products/52.jpg" class="img-responsive" alt=""></a>
				</div>
				<div class="col-md-8 col-xs-8 product-info">
					<h5><a href="#">Product name #01</a></h5>

					<div class="star-rating" title="Rated 4.50 out of 5">
						<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
					</div><!-- /.star-rating -->

					<div class="product-price">	
						<ins><span class="amount">$369,99</span></ins>
						<del><span class="amount">$400,99</span></del>
					</div><!-- /.product-price -->

				</div>
			</div>
		</div><!-- /.item -->
	</div><!-- /.product-item-small-owl -->
</div><!-- /.product-item-small -->
<!-- ============================================== DIGITAL BEST SELLER : END ============================================== -->
