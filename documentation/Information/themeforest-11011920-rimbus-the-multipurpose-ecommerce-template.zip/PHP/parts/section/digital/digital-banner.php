<!-- ============================================== DIGITAL BANNER ============================================== -->
<div class="container banner-non-link wow fadeInUp">
	<div class="row">
		<div class="col-md-4 col-sm-6 banner-1 wow fadeInUp" data-wow-delay="0.2s">
			<div class="banner-outer">
				<a href="#">
					<div class="image">
					    <img src="assets/images/banners/15.jpg" class="img-responsive" alt="#">
					</div>	
					<div class="text">
						<h4>samsung</h4>
						<h2>galax ys6</h2>
					</div>							
				</a>
			</div>
		</div><!-- /.col -->

		<div class="col-md-4 col-sm-6 banner-2 wow fadeInUp" data-wow-delay="0.4s">
			<div class="banner-outer ">
				<a href="#">
					<div class="image">
					    <img src="assets/images/banners/16.jpg" alt="#" class="img-responsive">
					</div>	
					<div class="text">
						<h4>apple watch</h4>
						<h2>watch sport</h2>
					</div>									
				</a>
			</div>
		</div><!-- /.col -->

		<div class="col-md-4 col-sm-12 banner-3 wow fadeInUp" data-wow-delay="0.6s">
			<div class="banner-outer">
				<a href="#">
					<div class="image">
					     <img src="assets/images/banners/17.jpg" alt="#" class="img-responsive">
					</div>	
					<div class="text">
						<h4>apple product</h4>
						<h2>new imouse</h2>
					</div>									
				</a>
			</div>
		</div><!-- /.col -->
	</div><!-- /.row -->
</div><!-- /.container -->
<!-- ============================================== DIGITAL BANNER : END ============================================== -->
