<!-- ============================================== FURNITURE SLIDER ============================================== -->
<div class="furniture-inner hero-style-3" id="hero">
	<div class="sliders owl-main owl-carousel owl-inner-nav owl-ui-lg" id="owl-main">
		<div class="item" style="background-image: url(assets/images/sliders/12.jpg);">
			<div class="slider-outer">
				<div class="content-1 caption vertical-center text-right">
					<h3 class="fadeInDown-1 ">new collection</h3>
					<h1 class="fadeInDown-2">sale off</h1>
					<h6 class="fadeInDown-3">Save up to 25% for all in your order.</h6>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item" style="background-image: url(assets/images/sliders/13.jpg);">
			<div class="slider-outer">
				<div class="content-2 caption vertical-center text-right">
					<h3 class="fadeInDown-1">furniture design</h3>
					<h1 class="fadeInDown-2">living room</h1>
					<h6 class="fadeInDown-3">Save up to 25% for all in your order in this month!</h6>
				</div>
			</div>
		</div><!-- /.item -->
		<div class="item" style="background-image: url(assets/images/sliders/14.jpg);">
			<div class="slider-outer">
				<div class="content-3 caption vertical-center text-right">
					<h3 class="fadeInDown-1">for new room</h3>
					<h1 class="fadeInDown-2">new design</h1>
					<h6 class="fadeInDown-3">See why our quality is best</h6>
				</div>
			</div>
		</div><!-- /.item -->
	</div><!-- /.sliders -->
</div><!-- /.furniture-inner -->
<!-- ============================================== FEATURED SLIDER : END ============================================== -->