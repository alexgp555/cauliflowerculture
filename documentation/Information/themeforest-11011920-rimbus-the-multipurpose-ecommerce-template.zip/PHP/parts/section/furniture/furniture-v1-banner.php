<!-- ============================================== FURNITURE-V1 BANNER ============================================== -->
<div class="banner-furniture-v1">
	<div class="banner-full">
		<div class="content">
			<span class="text-1">big</span>
			<span class="text-2">sale</span>
			<span class="text-3">25% OFF</span>
		</div>
		<img src="assets/images/banners/25.jpg" alt="#" class="img-responsive">
	</div><!-- /.banner-full -->
</div><!-- /.banner-furniture-v1 -->
<!-- ============================================== FURNITURE-V1 BANNER : END ============================================== -->