<!-- ============================================== FURNITURE-V2 BANNER ============================================== -->
<div class="banner-furniture-v2">
	<div class="banner-full">
		<div class="content">
			<span class="text-1">Rooms</span>
			<span class="text-2">we love</span>
			<span class="text-3">See how we put it together & shop the room.</span>
		</div>
		<img src="assets/images/banners/26.jpg" alt="#" class="img-responsive">
	</div><!-- /.banner-full -->
</div><!-- /.banner-furniture-v2 -->
<!-- ============================================== FURNITURE-V2 BANNER : END============================================== -->