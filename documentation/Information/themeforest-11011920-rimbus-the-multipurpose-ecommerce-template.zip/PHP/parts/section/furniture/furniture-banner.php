<!-- ============================================== FURNITURE BANNER ============================================== -->
<div class="col-md-4 col-sm-6 col-xs-12 banner-1 wow fadeInUp" data-wow-delay="0.2s">
	<div class="banner-outer">
		<a href="#">
			<div class="text">
				<h4>dining room</h4>
				<h2>accessories</h2>
			</div>
			<div class="image">
				<img src="assets/images/banners/27.jpg" class="img-responsive" alt="#">
			</div>
		</a>
	</div>
</div><!-- /.col -->
<div class="col-md-4 col-sm-6 col-xs-12 banner-2 wow fadeInUp" data-wow-delay="0.4s">
	<div class="banner-outer ">
		<a href="#">
			<div class="text">
				<h4>new design</h4>
				<h2>living room</h2>
			</div>
			<div class="image">
			<img src="assets/images/banners/28.jpg" alt="#" class="img-responsive">
			</div>
		</a>
	</div>
</div><!-- /.col -->
<div class="col-md-4 col-sm-12 col-xs-12 banner-3 wow fadeInUp" data-wow-delay="0.6s">
	<div class="banner-outer">
		<a href="#">
			<div class="text">
				<h4>bed room</h4>
				<h2>lookbook</h2>
			</div>
			<div class="image">
			<img src="assets/images/banners/29.jpg" alt="#" class="img-responsive">
			</div>
		</a>
	</div>
</div><!-- /.col -->
<!-- ============================================== FURNITURE BANNER : END ============================================== -->