<!-- ========================================== CATEGORY PAGE SLIDER ========================================= -->
<div class="clearfix"></div>
<div id="category" class="gird-v1-banner wow fadeIn">
	<div class="item">	
		<div class="image">
			<img src="assets/images/banners/1.jpg" alt="" class="img-responsive">
		</div>
		<div class="container-fluid">
			<div class="caption vertical-top">
				<div class="small-text wow fadeIn" data-wow-delay="0.2s">women’s</div>
				<div class="big-text wow fadeIn" data-wow-delay="0.4s">accessories</div>
				<div class="bottom-line wow fadeIn" data-wow-delay="0.6s">Save up to 25% for all in your order.</div>
			</div><!-- /.caption -->
		</div><!-- /.container-fluid -->
	</div><!-- /.item -->
</div><!-- /.gird-v1-banner -->
<!-- ========================================= CATEGORY PAGE SLIDER : END ========================================= -->