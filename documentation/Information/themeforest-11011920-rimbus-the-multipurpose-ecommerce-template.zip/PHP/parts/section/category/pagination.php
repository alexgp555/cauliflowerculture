<!-- ========================================== PAGINATION ========================================= -->
<nav>
	<ul class="pagination">
		<li>
			<a href="#" class="prev" aria-label="Previous">
				<span aria-hidden="true"><i class="fa fa-angle-left"></i></span>
			</a>
		</li>
		<li class="active" ><a href="#">1</a></li>
		<li><a href="#">2</a></li>
		<li><a href="#">3</a></li>
		<li>
			<a href="#" class="next" aria-label="Next">
				<span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
			</a>
		</li>
	</ul><!-- /.pagination -->
</nav>
<!-- ========================================== PAGINATION : END ========================================= -->