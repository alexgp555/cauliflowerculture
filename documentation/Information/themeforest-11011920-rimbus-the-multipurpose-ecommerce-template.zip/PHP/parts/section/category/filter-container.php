<!-- ==========================================FILTER CONTAINER ========================================= -->
<div class="custom-select">
	<section>	  
        <select class="styled">
            <option>Brands</option>
            <option>brands 1</option>
            <option>brands 2</option>
            <option>brands 3</option>
            <option>brands 4</option>
            <option>brands 5</option>
        </select>
    </section>

	<section>	  
        <select class="styled">
            <option>Price</option>
            <option>Low to High</option>
            <option>High to low</option>
            <option>50% off</option>
            <option>40% off</option>
            <option>30% off</option>
        </select>
    </section>

    <section>     
        <select class="styled">
            <option>Size</option>
            <option>Small</option>
            <option>Large</option>
            <option>XL</option>
            <option>XXL</option>
            <option>XXXL</option>
        </select>
    </section>

    <section>     
        <select class="styled">
            <option>Color</option>
            <option>Red</option>
            <option>Green</option>
            <option>Yellow</option>
            <option>Grey</option>
            <option>Black</option>
        </select>
    </section>

    <section>     
        <select class="styled">
            <option>PROPERTIES</option>
            <option>Properties 1</option>
            <option>Properties 2</option>
            <option>Properties 3</option>
            <option>Properties 4</option>
            <option>Properties 5</option>
        </select>
    </section>

    <section>     
        <select class="styled">
            <option>COMPOSITIONS</option>
            <option>compositions 1</option>
            <option>compositions 2</option>
            <option>compositions 3</option>
            <option>compositions 4</option>
            <option>compositions 5</option>
        </select>
    </section>

</div><!-- /.custom-select -->
<!-- ========================================== FILTER CONTAINER : END ========================================= -->