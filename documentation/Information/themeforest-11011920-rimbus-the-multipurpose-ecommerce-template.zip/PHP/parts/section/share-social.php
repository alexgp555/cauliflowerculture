<!-- ============================================== SOCIAL SHARING ============================================== -->
<div class="share-post">
	<script>
	window.___gcfg = {lang: 'en-US'};
	(function(w, d, s) {
	  function go(){
		var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
		  if (d.getElementById(id)) {return;}
		  js = d.createElement(s); js.src = url; js.id = id;
		  fjs.parentNode.insertBefore(js, fjs);
		};
		load('//connect.facebook.net/en/all.js#xfbml=1', 'fbjssdk');
		load('https://apis.google.com/js/plusone.js', 'gplus1js');
		load('//platform.twitter.com/widgets.js', 'tweetjs');
	  }
	  if (w.addEventListener) { w.addEventListener("load", go, false); }
	  else if (w.attachEvent) { w.attachEvent("onload",go); }
	}(window, document, 'script'));
	</script>
	<ul class="list-inline list-unstyled">			
		<li><iframe id="twitter-widget-0" scrolling="no" frameborder="0" allowtransparency="true" src="http://platform.twitter.com/widgets/tweet_button.c27d2d163408c0fe087fbfe1c687ce2b.en.html#_=1421163698868&amp;count=horizontal&amp;id=twitter-widget-0&amp;lang=en&amp;original_referer=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F&amp;size=m&amp;text=15%20Free%20HTML%20CSS3%20Social%20Media%20Buttons&amp;url=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F&amp;via=designscrazed" class="twitter-share-button twitter-tweet-button twitter-share-button twitter-count-horizontal" title="Twitter Tweet Button" data-twttr-rendered="true" style="width: 109px; height: 20px;"></iframe></li>
		<li>
			<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div><iframe name="fb_xdm_frame_http" frameborder="0" allowtransparency="true" scrolling="no" id="fb_xdm_frame_http" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="http://static.ak.facebook.com/connect/xd_arbiter/7r8gQb8MIqE.js?version=41#channel=f386ad1ff8&amp;origin=http%3A%2F%2Fdesignscrazed.org" style="border: none;"></iframe><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" scrolling="no" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="https://s-static.ak.facebook.com/connect/xd_arbiter/7r8gQb8MIqE.js?version=41#channel=f386ad1ff8&amp;origin=http%3A%2F%2Fdesignscrazed.org" style="border: none;"></iframe></div></div><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div></div></div>
			<div class="fb-like fb_iframe_widget" data-href="http://designscrazed.org/html-css3-social-media-buttons/" data-send="false" data-layout="button_count" data-width="90" data-show-faces="false" fb-xfbml-state="rendered" fb-iframe-plugin-query="app_id=412318062172764&amp;href=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F&amp;layout=button_count&amp;locale=en_GB&amp;sdk=joey&amp;send=false&amp;show_faces=false&amp;width=90"><span style="vertical-align: bottom; width: 76px; height: 20px;"><iframe name="f1639f982" width="90px" height="1000px" frameborder="0" allowtransparency="true" scrolling="no" title="fb:like Facebook Social Plugin" src="http://www.facebook.com/v2.0/plugins/like.php?app_id=412318062172764&amp;channel=http%3A%2F%2Fstatic.ak.facebook.com%2Fconnect%2Fxd_arbiter%2F7r8gQb8MIqE.js%3Fversion%3D41%23cb%3Df229765d8c%26domain%3Ddesignscrazed.org%26origin%3Dhttp%253A%252F%252Fdesignscrazed.org%252Ff386ad1ff8%26relation%3Dparent.parent&amp;href=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F&amp;layout=button_count&amp;locale=en_GB&amp;sdk=joey&amp;send=false&amp;show_faces=false&amp;width=90" style="border: none; visibility: visible; width: 76px; height: 20px;" class=""></iframe></span></div>
		</li>
		<li><div id="___plusone_0" style="text-indent: 0px; margin: 0px; padding: 0px; border-style: none; float: none; line-height: normal; font-size: 1px; vertical-align: baseline; display: inline-block; width: 90px; height: 20px; background: transparent;"><iframe frameborder="0" hspace="0" marginheight="0" marginwidth="0" scrolling="no" style="position: static; top: 0px; width: 90px; margin: 0px; border-style: none; left: 0px; visibility: visible; height: 20px;" tabindex="0" vspace="0" width="100%" id="I0_1421163699092" name="I0_1421163699092" src="https://apis.google.com/u/0/se/0/_/+1/fastbutton?usegapi=1&amp;size=medium&amp;hl=en-US&amp;origin=http%3A%2F%2Fdesignscrazed.org&amp;url=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F&amp;gsrc=3p&amp;ic=1&amp;jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.en_GB.-p91tm1WTXc.O%2Fm%3D__features__%2Fam%3DAQ%2Frt%3Dj%2Fd%3D1%2Ft%3Dzcms%2Frs%3DAGLTcCMr_eLs6Wen82vn_uEr8Qc8X5GDHw#_methods=onPlusOne%2C_ready%2C_close%2C_open%2C_resizeMe%2C_renderstart%2Concircled%2Cdrefresh%2Cerefresh%2Conload&amp;id=I0_1421163699092&amp;parent=http%3A%2F%2Fdesignscrazed.org&amp;pfname=&amp;rpctoken=19382355" data-gapiattached="true" title="+1"></iframe></div></li>
		<li><iframe scrolling="no" frameborder="0" allowtransparency="true" src="http://badge.stumbleupon.com/badge/embed/2/?url=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F" width="65" height="18" id="iframe-stmblpn-widget-1" style="overflow: hidden; margin: 0px; padding: 0px; border: 0px;"></iframe>
		<script type="text/javascript">
			(function() {
				var li = document.createElement('script'); li.type = 'text/javascript'; li.async = true;
				li.src = ('https:' == document.location.protocol ? 'https:' : 'http:') + '//platform.stumbleupon.com/1/widgets.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(li, s);
			})();
			</script>
		</li>
		<li><script src="http://platform.linkedin.com/in.js" type="text/javascript"></script><span class="IN-widget" style="line-height: 1; vertical-align: baseline; display: inline-block; text-align: center;"><span style="padding: 0px !important; margin: 0px !important; text-indent: 0px !important; display: inline-block !important; vertical-align: baseline !important; font-size: 1px !important;"><span id="li_ui_li_gen_1421163699570_0"><a id="li_ui_li_gen_1421163699570_0-link" href="javascript:void(0);"><span id="li_ui_li_gen_1421163699570_0-logo">in</span><span id="li_ui_li_gen_1421163699570_0-title"><span id="li_ui_li_gen_1421163699570_0-mark"></span><span id="li_ui_li_gen_1421163699570_0-title-text">Share</span></span></a></span></span><span style="padding: 0px !important; margin: 0px !important; text-indent: 0px !important; display: inline-block !important; vertical-align: baseline !important; font-size: 1px !important;"><span id="li_ui_li_gen_1421163699632_1-container" class="IN-right"><span id="li_ui_li_gen_1421163699632_1" class="IN-right"><span id="li_ui_li_gen_1421163699632_1-inner" class="IN-right"><span id="li_ui_li_gen_1421163699632_1-content" class="IN-right">5</span></span></span></span></span></span><script type="IN/Share+init" data-url="http://designscrazed.org/html-css3-social-media-buttons/" data-counter="right"></script></li>
		<li style="width:80px;"><a class="PIN_1421163700325_pin_it_button_20 PIN_1421163700325_pin_it_button_en_20_gray PIN_1421163700325_pin_it_button_inline_20 PIN_1421163700325_pin_it_beside_20" data-pin-href="//www.pinterest.com/pin/create/button/?guid=YTr1swfWWT6G-1&amp;url=http%3A%2F%2Fdesignscrazed.org%2Fhtml-css3-social-media-buttons%2F&amp;media=http%3A%2F%2Fdesignscrazed.org%2Fwp-content%2Fuploads%2F2014%2F03%2Fcircular-social-icons-590x330.jpg&amp;description=15%20Free%20HTML%20CSS3%20Social%20Media%20Buttons" data-pin-log="button_pinit" data-pin-config="beside"><span class="PIN_1421163700325_hidden" id="PIN_1421163700325_pin_count_0"><i></i></span></a></li>
		</ul>
	<div class="clear"></div>
</div><!-- /.share-post -->
<!-- ============================================== SOCIAL SHARING : END ============================================== -->