<!-- ============================================== BLOG WRITE COMMENTS ============================================== -->
<div class="blog-write-comment wow fadeInUp">
	<div class="row">
		<div class="col-md-12">
			<h4>leave a comment</h4>
		</div><!-- /.col -->
		<div class="col-md-4">
			<form class="register-form" role="form">
				<div class="form-group">
			    <input type="email" class="form-control text-input" id="exampleInputName" placeholder="Your Name ">
			  </div>
			</form>
		</div><!-- /.col -->
		<div class="col-md-4">
			<form class="register-form" role="form">
				<div class="form-group">
			    <input type="email" class="form-control text-input" id="exampleInputEmail1" placeholder="Your email">
			  </div>
			</form>
		</div><!-- /.col -->
		<div class="col-md-4">
			<form class="register-form" role="form">
				<div class="form-group">
			    	<input type="email" class="form-control text-input" id="exampleInputTitle" placeholder="Your website">
			  </div>
			</form>
		</div><!-- /.col -->
		<div class="col-md-12">
			<form class="register-form" role="form">
				<div class="form-group">
			    	<textarea class="form-control" id="exampleInputComments" placeholder="Your Comment"></textarea>
			  </div>
			</form>
		</div><!-- /.col -->
		<div class="col-md-12 outer-bottom-small">
			<button type="submit" class="btn-upper btn btn-primary checkout-page-button">Send Comment</button>
		</div><!-- /.col -->
	</div><!-- /.row -->
</div><!-- /.blog-write-comment -->
<!-- ============================================== BLOG WRITE COMMENTS : END ============================================== -->
