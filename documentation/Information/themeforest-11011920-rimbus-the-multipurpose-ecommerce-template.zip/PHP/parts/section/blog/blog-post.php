<!-- ============================================== BLOG POST ============================================== -->
<div class="blog-post wow fadeInUp">
	<a class="post-image" href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/1.jpg" alt="#"></a>
	<h1><a href="index.php?page=blog-single">30 Beautiful and Creative Ecommerce Website</a></h1>
	<span class="author-date">By Admin - Jan 21,2015</span>
	<p>Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Ut ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maecenas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vitae enim est. Phasellus fermentum odio quam. Donec aliquam lacinia nisi, idrhs oncus sapien pharetra ac. Quisque sed pharetra eros, at molestie erat [...]</p>
	<a href="index.php?page=blog-single" class="btn btn-upper btn-primary">read more</a>
</div><!-- /.blog-post -->

<div class="blog-post wow fadeInUp">
	<h1><a href="index.php?page=blog-single">30 Beautiful and Creative Ecommerce Website</a></h1>
	<span class="author-date">By Admin - Jan 21,2015</span>
	<p>Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Ut ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maecenas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vitae enim est. Phasellus fermentum odio quam. Donec aliquam lacinia nisi, idrhs oncus sapien pharetra ac. Quisque sed pharetra eros, at molestie erat [...]</p>
	<a href="index.php?page=blog-single" class="btn btn-upper btn-primary">read more</a>
</div><!-- /.blog-post -->

<div class="blog-post wow fadeInUp">
	<a class="post-image" href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/2.jpg" alt="#"></a>
	<h1><a href="index.php?page=blog-single">30 Beautiful and Creative Ecommerce Website</a></h1>
	<span class="author-date">By Admin - Jan 21,2015</span>
	<p>Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Ut ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maecenas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vitae enim est. Phasellus fermentum odio quam. Donec aliquam lacinia nisi, idrhs oncus sapien pharetra ac. Quisque sed pharetra eros, at molestie erat [...]</p>
	<a href="index.php?page=blog-single" class="btn btn-upper btn-primary">read more</a>
</div><!-- /.blog-post -->

<div class="blog-post wow fadeInUp">
	<a class="post-image" href="index.php?page=blog-single"><img class="img-responsive" src="assets/images/blog/3.jpg" alt="#"></a>
	<h1><a href="index.php?page=blog-single">30 Beautiful and Creative Ecommerce Website</a></h1>
	<span class="author-date">By Admin - Jan 21,2015</span>
	<p>Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Ut ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maecenas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vitae enim est. Phasellus fermentum odio quam. Donec aliquam lacinia nisi, idrhs oncus sapien pharetra ac. Quisque sed pharetra eros, at molestie erat [...]</p>
	<a href="index.php?page=blog-single" class="btn btn-upper btn-primary">read more</a>
</div><!-- /.blog-post -->
<!-- ============================================== BLOG POST : END ============================================== -->