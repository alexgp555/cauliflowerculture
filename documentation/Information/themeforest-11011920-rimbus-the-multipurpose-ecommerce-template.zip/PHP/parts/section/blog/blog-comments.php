<!-- ============================================== BLOG COMMENTS ============================================== -->
<div class="blog-comments wow fadeInUp">
	<h3 class="title">Comments<span class="comments-count">(04)</span></h3>
	
	<ul class="media-list">
		<li class="media">
			<div class="media-left">
				<a href="#">
					<img class="media-object" src="assets/images/blog/11.jpg" alt="#">
				</a>
			</div>
			<div class="media-body">
				<h4 class="media-heading">Doe Jone</h4>
				<div class="comment-action">
					<ul class="list-inline list-unstyled">
						<li>03 days ago</li>
						<li><a href="#">repost</a></li>
						<li><a href="#">reply</a></li>
					</ul>
				</div>
				<p class="primary-comment">Aliquam tristique bibendum velit vel pellentesque. Morbi eget semper ipsum. Maecenas cursus perdiet leo, egestas ullamcorper mauris mattis et. Aenean posuere feugiat fermentum serts. Maecenas mentum sollicitudin congue. </p>
				<div class="media secondary-comment">
		            <div class="media-left">
		            	<a href="#">
		              		<img class="media-object" src="assets/images/blog/11.jpg" alt="#">
		            	</a>
		            </div>
		            <div class="media-body">
		            	<h4 class="media-heading">Alexan</h4>
						<div class="comment-action">
							<ul class="list-inline list-unstyled">
								<li>03 days ago</li>
								<li><a href="#">repost</a></li>
								<li><a href="#">reply</a></li>
							</ul>
						</div>
						<p>Aliquam tristique bibendum velit vel pellentesque. Morbi eget semper ipsum. Maecenas cursus perdiet leo, egestas ullam.</p>
		            </div>
		        </div>
		        <div class="media secondary-comment">
		            <div class="media-left">
		            	<a href="#">
		              		<img class="media-object" src="assets/images/blog/11.jpg" alt="#">
		            	</a>
		            </div>
		            <div class="media-body">
		            	<h4 class="media-heading">Doe Jone</h4>
						<div class="comment-action">
							<ul class="list-inline list-unstyled">
								<li>03 days ago</li>
								<li><a href="#">repost</a></li>
								<li><a href="#">reply</a></li>
							</ul>
						</div>
						<p>Aliquam tristique bibendum velit vel pellentesque. Morbi eget semper ipsum. Maecenas cursus perdiet leo, egestas ullam.</p>
		            </div>
		        </div>
			</div>
		</li><!-- /.media -->
	</ul><!-- /.media-list -->

	<ul class="media-list">
		<li class="media">
			<div class="media-left">
				<a href="#">
					<img class="media-object" src="assets/images/blog/11.jpg" alt="#">
				</a>
			</div>
			<div class="media-body">
				<h4 class="media-heading">Ammaar ibnu anas</h4>
				<div class="comment-action">
					<ul class="list-inline list-unstyled">
						<li>03 days ago</li>
						<li><a href="#">repost</a></li>
						<li><a href="#">reply</a></li>
					</ul>
				</div>
				<p>Aliquam tristique bibendum velit vel pellentesque. Morbi eget semper ipsum. Maecenas cursus perdiet leo, egestas ullamcorper mauris mattis et. Aenean posuere feugiat fermentum serts. Maecenas mentum sollicitudin congue. </p>
			</div>
		</li><!-- /.media -->
	</ul><!-- /.media-list -->
</div><!-- /.blog-comments -->
<!-- ============================================== BLOG COMMENTS : END ============================================== -->