<!-- ============================================== BLOG SINGLE POST ============================================== -->
<div class="blog-single-post wow fadeInUp">
	<img class="img-responsive" src="assets/images/blog/1.jpg" alt="#">
	<h1>30 Beautiful and Creative Ecommerce Website</h1>
	<span class="author-date">By Admin - Jan 21,2015</span>
	<div class="blog-content">
		<p>Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Ut ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maecenas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vitae enim est. Phasellus fermentum odio quam. Donec aliquam lacinia nisi, idrhs oncus sapien pharetra ac. </p>
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<p class="">Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Utsd ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maec enas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vita enims est. Phasellus fermentum odio quam. Donec aliquam lacini a nisi idrhses oncus sapien pharetra ac. Quisque sed pharetra eros, at molestie eratsd. Maecenas quis risus tristique, vehicula sem. Donec vitae enim est. Phas ellus fermentum odio quam. Donec vitae enim est. Donec vitae enim.</p>
			</div>
			<div class="col-md-6 col-sm-6">
				<span class=""><img class="img-responsive" src="assets/images/blog/10.jpg" alt=""></span>	
			</div>			
		</div>
		<p class="last-para">Cras condimentum venenatis enim a facilisis. Fusce in mauris velit. Ut ipsum lectus, laoreet ac condimentum nec, rhoncus ac augue. Maecenas sollicitudin euismod congue. Nunc in vestibulum arcu. Donec vitae enim est. Phasellus fermentum odio quam. Donec aliquam lacinia nisi, idrhs oncus sapien pharetra ac. Quisque sed pharetra eros, at molestie erat. Maecenas quis risus tristique, vehicula sem. Donec vitae enim est. Phas ellus fermentum odio quam. </p>
	</div><!-- /.blog-content -->

	<div class="cat-tags">
		<span class="cat-links">
			<span class="tags-title">tags:</span>
			<a href="#" rel="category tag">Rokan</a>, 
			<a href="#" rel="category tag">Blog</a>,
			<a href="#" rel="category tag">PSD</a>,
			<a href="#" rel="category tag">Wordpress</a>
		</span>
	</div><!-- /.cat-tags -->
	
	<div class="share">
		<span class="share-title">share:</span>
		<a href="#"><i class="fa fa-facebook"></i></a>
		<a href="#"><i class="fa fa-twitter"></i></a>
		<a href="#"><i class="fa fa-google-plus"></i></a>
		<a href="#"><i class="fa fa-tumblr"></i></a>
	</div><!-- /.share -->
</div><!-- /.blog-single-post -->
<!-- ============================================== BLOG SINGLE POST : END ============================================== -->