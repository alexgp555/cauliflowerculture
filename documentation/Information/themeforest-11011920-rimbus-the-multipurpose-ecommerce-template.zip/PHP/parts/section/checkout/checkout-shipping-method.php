<!-- ========================================== CHECKOUT SHIPPING METHOD ========================================= -->
<div class="row">		

	<div class="col-md-12 col-sm-12 guest-login">
		<h5 class="checkout-subtitle">SHIPPING AND HANDLING</h5>
		
		<form role="form" class="register-form">
		    <div class="radio">  
		        <input type="radio" checked="" value="flatrate" name="text" id="flatrate">  
		        <label for="flatrate" class="radio-button">Flat Rate: £2.90</label>  
		          <br>
		        <input type="radio" value="freeshipping" name="text" id="freeshipping">  
		        <label for="freeshipping" class="radio-button">Free Shipping</label>  
		    </div>  
		</form>
		
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<button class="btn-upper btn btn-primary" type="submit">continue</button>
	</div><!-- /.col -->

</div><!-- /.row -->
<!-- ========================================== CHECKOUT SHIPPING METHOD : END ========================================= -->