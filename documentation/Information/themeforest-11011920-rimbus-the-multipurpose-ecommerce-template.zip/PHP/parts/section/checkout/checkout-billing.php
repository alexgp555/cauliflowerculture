<!-- ========================================== CHECKOUT BILLING ========================================= -->
<div class="row billing">		

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
		    	<label for="exampleInputfirstname" class="info-title">First Name <span>*</span></label>
		    	<input type="text" placeholder="" id="exampleInputfirstname" class="form-control text-input">
		  	</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputlastname" class="info-title">Last Name <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputlastname" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->
	
	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputaddress" class="info-title">Address Line 1 <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputaddress" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputaddress2" class="info-title">Address Line 2</label>
			    <input type="text" placeholder="" id="exampleInputaddress2" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->
	
	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputcompanyname" class="info-title">Country <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputcompanyname" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputcitytown" class="info-title">city/town <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputcitytown" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputstate" class="info-title">state <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputstate" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputpostcode" class="info-title">postcode <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputpostcode" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputemailid" class="info-title">email-address <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputemailid" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputmobile" class="info-title">mobile <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputmobile" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<button class="btn-upper btn btn-primary" type="submit">continue</button>
	</div><!-- /.col -->
			
</div><!-- /.row -->
<!-- ========================================== CHECKOUT BILLING : END ========================================= -->