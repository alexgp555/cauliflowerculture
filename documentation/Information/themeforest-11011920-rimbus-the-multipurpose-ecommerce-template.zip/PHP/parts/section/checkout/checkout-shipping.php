<!-- ========================================== CHECKOUT SHIPPING ========================================= -->
<div class="row billing">
	<div class="col-md-12 col-sm-12 form-rimbus">		
		<div class="form-group">
		    <div class="checkbox">
		        <label>
		          <input type="checkbox"> Ship to a different address?
		        </label>
		    </div>
	  	</div>
  	</div><!-- /.col -->
  	
	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
		    	<label for="exampleInputfirstname1" class="info-title">First Name <span>*</span></label>
		    	<input type="text" placeholder="" id="exampleInputfirstname1" class="form-control text-input">
		  	</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputlastname1" class="info-title">Last Name <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputlastname1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputcompanyname1" class="info-title">Company Name</label>
			    <input type="text" placeholder="" id="exampleInputcompanyname1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputaddress1" class="info-title">Address Line 1 <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputaddress1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputaddress1.1" class="info-title">Address Line 2</label>
			    <input type="text" placeholder="" id="exampleInputaddress1.1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputcitytown1" class="info-title">city/town <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputcitytown1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputstate1" class="info-title">state <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputstate1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputpostcode1" class="info-title">postcode <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputpostcode1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputemailid1" class="info-title">email-address <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputemailid1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<form role="form" class="register-form">
			<div class="form-group">
			    <label for="exampleInputmobile1" class="info-title">mobile <span>*</span></label>
			    <input type="text" placeholder="" id="exampleInputmobile1" class="form-control text-input">
			</div>
		</form>
	</div><!-- /.col -->

	<div class="col-md-6 col-sm-6 form-rimbus">
		<button class="btn-upper btn btn-primary" type="submit">continue</button>
	</div><!-- /.col -->
			
</div><!-- /.row -->
<!-- ========================================== CHECKOUT SHIPPING : END ========================================= -->