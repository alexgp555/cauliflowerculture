<!-- ============================================== FOOD BEST SELLER ============================================== -->
<div class="product-item-small">
	<div class="title">
		<h3>drink</h3>
		<hr>
	</div><!-- /.title -->

	<div class="product-item-sm">
		<div class="media products-small">
			<div class="media-left product-image">
				<a href="#"><img src="assets/images/products/102.jpg" class="img-responsive" alt=""></a>
			</div>
			<div class="media-body product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="media products-small">
			<div class="media-left product-image">
				<a href="#"><img src="assets/images/products/103.jpg" class="img-responsive" alt=""></a>
			</div>
			<div class="media-body product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="media products-small">
			<div class="media-left product-image">
				<a href="#"><img src="assets/images/products/104.jpg" class="img-responsive" alt=""></a>
			</div>
			<div class="media-body product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->
			</div>
		</div>
	</div><!-- /.product-item-sm -->
</div><!-- /.product-item-small -->
<!-- ============================================== FOOD BEST SELLER : END ============================================== -->