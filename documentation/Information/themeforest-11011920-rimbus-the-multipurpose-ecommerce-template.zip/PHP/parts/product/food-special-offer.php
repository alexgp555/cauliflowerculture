<!-- ============================================== FOOD SPECIAL OFFER ============================================== -->
<div class="product-item-small">
	<div class="title">
		<h3>main courses</h3>
		<hr>
	</div>

	<div class="product-item-sm">

		<div class="media products-small">
			<div class="media-left product-image">
				<a href="#"><img src="assets/images/products/120.jpg" class="img-responsive" alt=""></a>
			</div>
			<div class="media-body product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="media products-small">
			<div class="media-left product-image">
				<a href="#"><img src="assets/images/products/121.jpg" class="img-responsive" alt=""></a>
			</div>
			<div class="media-body product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->

			</div>
		</div>

		<div class="media products-small">
			<div class="media-left product-image">
				<a href="#"><img src="assets/images/products/122.jpg" class="img-responsive" alt=""></a>
			</div>
			<div class="media-body product-info">
				<h5><a href="#">Product name #01</a></h5>

				<div class="star-rating" title="Rated 4.50 out of 5">
					<span style="width:90%"><strong class="rating">4.50</strong> out of 5</span>
				</div><!-- /.star-rating -->

				<div class="product-price">	
					<ins><span class="amount">$369,99</span></ins>
					<del><span class="amount">$400,99</span></del>
				</div><!-- /.product-price -->
			</div>
		</div>

	</div><!-- /.product-item-sm -->
</div><!-- /.product-item-small -->
<!-- ============================================== FOOD SPECIAL OFFER : END ============================================== -->
