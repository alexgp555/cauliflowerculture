<!-- ========================================= CONTENT ========================================= -->
<div class="body-content">

	<div class="headers inner-bottom-sm">
		<div class="header-v1 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v1.php';?>
		</div><!-- /.header-v1 -->
		<div class="header-v2 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v2.php';?>
		</div><!-- /.header-v2 -->
		<div class="header-v3 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v3.php';?>
		</div><!-- /.header-v3 -->
		<div class="header-v4 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v4.php';?>
		</div><!-- /.header-v4 -->
		<div class="header-v5 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v5.php';?>
		</div><!-- /.header-v5 -->
		<div class="header-v6 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v6.php';?>
		</div><!-- /.header-v6 -->
		<div class="header-v7 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v7.php';?>
		</div><!-- /.header-v7 -->
		<div class="header-v8 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v8.php';?>
		</div><!-- /.header-v8 -->
		<div class="header-v9 outer-top">
			<?php require RB_ROOT.'/parts/section/header/header-v9.php';?>
		</div><!-- /.header-v9 -->
	</div><!-- /.headers -->
</div><!-- /.body-content -->
<!-- ========================================= CONTENT : END========================================= -->