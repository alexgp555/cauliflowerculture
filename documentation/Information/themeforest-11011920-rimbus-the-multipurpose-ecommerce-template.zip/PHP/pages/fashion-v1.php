<!-- ========================================= CONTENT ========================================= -->
<div class="body-content fashion-v1-position">
	<?php require RB_ROOT.'/parts/section/fashion/fashionv1-slider.php' ?>
</div><!-- /.body-content -->
<!-- ========================================= CONTENT : END========================================= -->
