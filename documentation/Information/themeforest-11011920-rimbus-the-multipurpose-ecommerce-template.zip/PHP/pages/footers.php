<!-- ========================================= CONTENT ========================================= -->
<div class="footers">
	<div class="footer-v1 outer-top-md">
		<?php require RB_ROOT.'/parts/section/footer/footer-v1.php';?>
	</div><!-- /.footer-v1 -->
	<div class="footer-v2 outer-top-md">
		<?php require RB_ROOT.'/parts/section/footer/footer-v2.php';?>
	</div><!-- /.footer-v2 -->
	<div class="footer-v3 outer-top-md">
		<?php require RB_ROOT.'/parts/section/footer/footer-v3.php';?>
	</div><!-- /.footer-v3 -->
	<div class="footer-v4 outer-top-md">
		<?php require RB_ROOT.'/parts/section/footer/footer-v4.php';?>
	</div><!-- /.footer-v4 -->
	<div class="footer-v5 outer-top-md">
		<?php require RB_ROOT.'/parts/section/footer/footer-v5.php';?>
	</div><!-- /.footer-v5 -->
</div><!-- /.footers -->

<!-- ========================================= CONTENT : END========================================= -->
